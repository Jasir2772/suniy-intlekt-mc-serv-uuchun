package uz.capmine.capai;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Har bir o'yinchi uchun oxirgi savol-javoblar (faqat xotirada). */
public final class ChatHistory {
    private final Map<UUID, Deque<String[]>> data = new ConcurrentHashMap<>();

    public List<String[]> get(UUID id) {
        Deque<String[]> d = data.get(id);
        if (d == null) return List.of();
        synchronized (d) {
            return new ArrayList<>(d);
        }
    }

    public void add(UUID id, String question, String answer, int maxPairs) {
        if (maxPairs <= 0) return;
        Deque<String[]> d = data.computeIfAbsent(id, k -> new ArrayDeque<>());
        synchronized (d) {
            d.addLast(new String[]{question, answer});
            while (d.size() > maxPairs) d.removeFirst();
        }
    }

    public void clear(UUID id) {
        data.remove(id);
    }
}
