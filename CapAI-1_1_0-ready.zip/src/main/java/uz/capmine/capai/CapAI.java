package uz.capmine.capai;

import org.bukkit.command.PluginCommand;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

public final class CapAI extends JavaPlugin implements Listener {
    private AIClient aiClient;
    private CooldownManager cooldownManager;
    private UsageManager usageManager;
    private ChatHistory chatHistory;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        aiClient = new AIClient(this);
        cooldownManager = new CooldownManager();
        usageManager = new UsageManager(this);
        chatHistory = new ChatHistory();

        AICommand command = new AICommand(this);
        PluginCommand pc = getCommand("ai");
        if (pc != null) {
            pc.setExecutor(command);
            pc.setTabCompleter(command);
        }
        getServer().getPluginManager().registerEvents(this, this);

        getLogger().info("CapAI v" + getDescription().getVersion() + " ishga tushdi!");
    }

    @Override
    public void onDisable() {
        if (usageManager != null) usageManager.save();
    }

    public void reloadAll() {
        reloadConfig();
        aiClient = new AIClient(this);
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        cooldownManager.clear(event.getPlayer().getUniqueId());
        chatHistory.clear(event.getPlayer().getUniqueId());
    }

    public AIClient getAIClient() { return aiClient; }
    public CooldownManager getCooldownManager() { return cooldownManager; }
    public UsageManager getUsageManager() { return usageManager; }
    public ChatHistory getChatHistory() { return chatHistory; }
}
