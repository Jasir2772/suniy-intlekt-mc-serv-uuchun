package uz.capmine.capai;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.bukkit.configuration.file.FileConfiguration;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.List;

public final class AIClient {
    private final CapAI plugin;
    private final HttpClient http;

    public AIClient(CapAI plugin) {
        this.plugin = plugin;
        int timeout = plugin.getConfig().getInt("settings.timeout-seconds", 20);
        this.http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(timeout)).build();
    }

    public String getApiKey() {
        return plugin.getConfig().getString("api.key", "").trim();
    }

    private static void addMessage(JsonArray messages, String role, String content) {
        JsonObject m = new JsonObject();
        m.addProperty("role", role);
        m.addProperty("content", content);
        messages.add(m);
    }

    public String ask(String playerName, String question, List<String[]> history) throws Exception {
        FileConfiguration cfg = plugin.getConfig();
        String url = cfg.getString("api.url", "https://api.openai.com/v1/chat/completions");
        String model = cfg.getString("api.model", "gpt-4o-mini");
        int timeout = cfg.getInt("settings.timeout-seconds", 20);
        int maxTokens = cfg.getInt("settings.max-tokens", 500);
        String serverInfo = cfg.getString("settings.server-info", "").trim();

        String system = """
                Sen CapMine Minecraft serverining CapAI yordamchisisan.
                Faqat foydali, odobli va xavfsiz javob ber.
                Foydalanuvchi o'zbekcha yozsa, o'zbekcha javob ber.
                Javoblarni qisqa va tushunarli qil, chunki Minecraft chatida uzun matn noqulay.
                Markdown belgilarini (**, #, `) ishlatma, oddiy matn yoz.
                Server komandalarini uydirma qilma; aniq bilmasang buni ayt.
                O'yinchining ismi: %s
                """.formatted(playerName);
        if (!serverInfo.isEmpty()) {
            system += "\nServer haqida ma'lumot:\n" + serverInfo + "\n";
        }

        JsonArray messages = new JsonArray();
        addMessage(messages, "system", system);
        for (String[] pair : history) {
            addMessage(messages, "user", pair[0]);
            addMessage(messages, "assistant", pair[1]);
        }
        addMessage(messages, "user", question);

        JsonObject body = new JsonObject();
        body.addProperty("model", model);
        body.add("messages", messages);
        body.addProperty("temperature", 0.7);
        if (maxTokens > 0) body.addProperty("max_tokens", maxTokens);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .timeout(Duration.ofSeconds(timeout))
                .header("Authorization", "Bearer " + getApiKey())
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(body.toString()))
                .build();

        HttpResponse<String> response = http.send(request, HttpResponse.BodyHandlers.ofString());

        if (response.statusCode() < 200 || response.statusCode() >= 300) {
            String err = response.body();
            if (err != null && err.length() > 300) err = err.substring(0, 300) + "...";
            throw new IllegalStateException("HTTP " + response.statusCode() + ": " + err);
        }

        JsonObject json = JsonParser.parseString(response.body()).getAsJsonObject();
        JsonArray choices = json.getAsJsonArray("choices");
        if (choices == null || choices.isEmpty()) throw new IllegalStateException("AI javob qaytarmadi.");

        JsonElement content = choices.get(0).getAsJsonObject()
                .getAsJsonObject("message")
                .get("content");
        if (content == null || content.isJsonNull() || content.getAsString().isBlank())
            throw new IllegalStateException("AI bo'sh javob qaytardi.");

        return content.getAsString().trim();
    }
}
