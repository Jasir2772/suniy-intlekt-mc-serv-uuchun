package uz.capmine.capai;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Kunlik savollar sonini hisoblaydi va usage.yml ga saqlaydi. */
public final class UsageManager {
    private final CapAI plugin;
    private final File file;
    private final Map<UUID, Integer> counts = new ConcurrentHashMap<>();
    private LocalDate date;

    public UsageManager(CapAI plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "usage.yml");
        this.date = today();
        load();
    }

    private LocalDate today() {
        String tz = plugin.getConfig().getString("settings.timezone", "Asia/Tashkent");
        ZoneId zone;
        try {
            zone = ZoneId.of(tz);
        } catch (Exception e) {
            zone = ZoneId.systemDefault();
        }
        return LocalDate.now(zone);
    }

    private void load() {
        if (!file.exists()) return;
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        if (!date.toString().equals(yaml.getString("date", ""))) return;
        ConfigurationSection section = yaml.getConfigurationSection("counts");
        if (section == null) return;
        for (String key : section.getKeys(false)) {
            try {
                counts.put(UUID.fromString(key), section.getInt(key));
            } catch (IllegalArgumentException ignored) {
            }
        }
    }

    private void rollover() {
        LocalDate now = today();
        if (!now.equals(date)) {
            date = now;
            counts.clear();
        }
    }

    public synchronized int used(UUID uuid) {
        rollover();
        return counts.getOrDefault(uuid, 0);
    }

    public synchronized void increment(UUID uuid) {
        rollover();
        counts.merge(uuid, 1, Integer::sum);
        saveAsync();
    }

    public synchronized void refund(UUID uuid) {
        rollover();
        counts.computeIfPresent(uuid, (k, v) -> v > 1 ? v - 1 : null);
        saveAsync();
    }

    private void saveAsync() {
        if (!plugin.isEnabled()) return;
        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, this::save);
    }

    public synchronized void save() {
        rollover();
        YamlConfiguration yaml = new YamlConfiguration();
        yaml.set("date", date.toString());
        for (Map.Entry<UUID, Integer> e : counts.entrySet()) {
            yaml.set("counts." + e.getKey(), e.getValue());
        }
        try {
            plugin.getDataFolder().mkdirs();
            yaml.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("usage.yml saqlanmadi: " + ex.getMessage());
        }
    }
}
