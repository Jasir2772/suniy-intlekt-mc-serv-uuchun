package uz.capmine.capai;

import org.bukkit.ChatColor;
import org.bukkit.command.*;
import org.bukkit.entity.Player;
import java.util.List;
import java.util.concurrent.CompletableFuture;

public final class AICommand implements CommandExecutor, TabCompleter {
    private final CapAI plugin;

    public AICommand(CapAI plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String prefix = color(plugin.getConfig().getString("messages.prefix", "&8[&bCapAI&8] &f"));

        if (!(sender instanceof Player player)) {
            sender.sendMessage(prefix + "Bu komanda faqat o'yinchi uchun.");
            return true;
        }
        if (!player.hasPermission("capai.use")) {
            player.sendMessage(prefix + color(plugin.getConfig().getString("messages.no-permission")));
            return true;
        }
        if (args.length == 0) {
            player.sendMessage(prefix + color(plugin.getConfig().getString("messages.usage")));
            return true;
        }

        String question = String.join(" ", args).trim();
        int maxLength = plugin.getConfig().getInt("settings.max-question-length", 300);
        if (question.length() > maxLength) {
            player.sendMessage(prefix + color(plugin.getConfig().getString("messages.too-long")));
            return true;
        }

        long cooldown = plugin.getConfig().getLong("settings.cooldown-seconds", 5);
        if (!player.hasPermission("capai.bypass")) {
            long remaining = plugin.getCooldownManager().remaining(player.getUniqueId(), cooldown);
            if (remaining > 0) {
                player.sendMessage(prefix + color(plugin.getConfig()
                    .getString("messages.cooldown", "&eYana &f%seconds% &esoniya kuting.")
                    .replace("%seconds%", String.valueOf(remaining))));
                return true;
            }
            plugin.getCooldownManager().mark(player.getUniqueId());
        }

        if (plugin.getAIClient().getApiKey().isBlank()) {
            player.sendMessage(prefix + color(plugin.getConfig().getString("messages.no-key")));
            return true;
        }

        player.sendMessage(prefix + color(plugin.getConfig().getString("messages.thinking")));

        CompletableFuture.runAsync(() -> {
            String answer;
            try {
                answer = plugin.getAIClient().ask(player.getName(), question);
            } catch (Exception e) {
                plugin.getLogger().warning("CapAI error: " + e.getMessage());
                answer = plugin.getConfig().getString("messages.error", "&cAI bilan bog'lanishda xatolik yuz berdi.");
            }

            final String result = answer;
            plugin.getServer().getScheduler().runTask(plugin, () -> sendWrapped(player, prefix, result));
        });
        return true;
    }

    private void sendWrapped(Player player, String prefix, String text) {
        int max = plugin.getConfig().getInt("settings.max-answer-length", 1200);
        if (text.length() > max) text = text.substring(0, max) + "...";
        for (String line : text.split("\\R")) player.sendMessage(prefix + color(line));
    }

    private String color(String text) {
        return ChatColor.translateAlternateColorCodes('&', text == null ? "" : text);
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        return List.of();
    }
}
