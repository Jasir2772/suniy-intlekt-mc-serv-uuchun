package uz.capmine.capai;

import com.google.gson.*;
import java.net.URI;
import java.net.http.*;
import java.time.Duration;

public final class AIClient {
    private final CapAI plugin;
    private final HttpClient http;

    public AIClient(CapAI plugin) {
        this.plugin = plugin;
        int timeout = plugin.getConfig().getInt("settings.timeout-seconds", 20);
        this.http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(timeout)).build();
    }

    public String getApiKey() {
        return plugin.getConfig().getString("api.key", "");
    }

    public String ask(String playerName, String question) throws Exception {
        String url = plugin.getConfig().getString("api.url");
        String model = plugin.getConfig().getString("api.model", "gpt-4o-mini");

        String system = """
                Sen CapMine Minecraft serverining CapAI yordamchisisan.
                Faqat foydali, odobli va xavfsiz javob ber.
                Foydalanuvchi o'zbekcha yozsa, o'zbekcha javob ber.
                Javoblarni qisqa va tushunarli qil.
                Server komandalarini uydirma qilma; aniq bilmasang buni ayt.
                O'yinchining ismi: %s
                """.formatted(playerName);

        JsonObject body = new JsonObject();
        body.addProperty("model", model);

        JsonArray messages = new JsonArray();

        JsonObject sys = new JsonObject();
        sys.addProperty("role", "system");
        sys.addProperty("content", system);
        messages.add(sys);

        JsonObject user = new JsonObject();
        user.addProperty("role", "user");
        user.addProperty("content", question);
        messages.add(user);

        body.add("messages", messages);
        body.addProperty("temperature", 0.7);

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .timeout(Duration.ofSeconds(plugin.getConfig().getInt("settings.timeout-seconds", 20)))
                .header("Authorization", "Bearer " + getApiKey())
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(body.toString()))
                .build();

        HttpResponse<String> response = http.send(request, HttpResponse.BodyHandlers.ofString());

        if (response.statusCode() < 200 || response.statusCode() >= 300)
            throw new IllegalStateException("HTTP " + response.statusCode() + ": " + response.body());

        JsonObject json = JsonParser.parseString(response.body()).getAsJsonObject();
        JsonArray choices = json.getAsJsonArray("choices");
        if (choices == null || choices.isEmpty()) throw new IllegalStateException("AI javob qaytarmadi.");

        return choices.get(0).getAsJsonObject()
                .getAsJsonObject("message")
                .get("content").getAsString();
    }
}
