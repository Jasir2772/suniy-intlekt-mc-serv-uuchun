package uz.capmine.capai;

import org.bukkit.plugin.java.JavaPlugin;

public final class CapAI extends JavaPlugin {
    private AIClient aiClient;
    private CooldownManager cooldownManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        aiClient = new AIClient(this);
        cooldownManager = new CooldownManager();

        getCommand("ai").setExecutor(new AICommand(this));
        getCommand("ai").setTabCompleter(new AICommand(this));

        getLogger().info("CapAI v" + getDescription().getVersion() + " ishga tushdi!");
    }

    public AIClient getAIClient() {
        return aiClient;
    }

    public CooldownManager getCooldownManager() {
        return cooldownManager;
    }
}
