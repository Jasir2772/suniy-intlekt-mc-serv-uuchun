package uz.capmine.capai;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class CooldownManager {
    private final Map<UUID, Long> lastUse = new ConcurrentHashMap<>();

    public long remaining(UUID uuid, long cooldownSeconds) {
        Long last = lastUse.get(uuid);
        if (last == null) return 0;

        long elapsed = System.currentTimeMillis() - last;
        long remaining = cooldownSeconds * 1000L - elapsed;
        return Math.max(0, (remaining + 999) / 1000);
    }

    public void mark(UUID uuid) {
        lastUse.put(uuid, System.currentTimeMillis());
    }
}
