plugins {
    java
    id("com.github.johnrengelman.shadow") version "8.1.1"
}

group = "uz.capmine"
version = "1.0.0"

repositories {
    mavenCentral()
    maven("https://repo.papermc.io/repository/maven-public/")
}

dependencies {
    compileOnly("io.papermc.paper:paper-api:1.21.4-R0.1-SNAPSHOT")
    implementation("com.google.code.gson:gson:2.11.0")
}

java {
    toolchain.languageVersion.set(JavaLanguageVersion.of(21))
}

tasks {
    jar { enabled = false }
    shadowJar {
        archiveClassifier.set("")
        relocate("com.google.gson", "uz.capmine.capai.libs.gson")
    }
    build { dependsOn(shadowJar) }
}
