package uz.capmine.capai;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

/** Telegram: xabar yuborish, buyruq qabul qilish, konsol boshqaruvi va chat ko'prigi. */
public final class TelegramBot {
    private static final Pattern COLOR = Pattern.compile("(?i)[&§][0-9a-fk-or]");
    private static final Set<String> KNOWN = Set.of(
            "start", "help", "status", "crash", "check", "ask", "mutes", "unmute", "players", "mute", "kick",
            "console", "cmd", "stop", "restart", "forcerestart", "kill", "yes", "no");

    private static final class Pending {
        final String desc;
        final Runnable action;
        final long expires;

        Pending(String desc, Runnable action, long expires) {
            this.desc = desc;
            this.action = action;
            this.expires = expires;
        }
    }

    private final CapAI plugin;
    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build();
    private final ScheduledExecutorService sender = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread t = new Thread(r, "CapAI-TG-Send");
        t.setDaemon(true);
        return t;
    });
    private final Map<String, Pending> pending = new ConcurrentHashMap<>();
    private final StringBuilder bridgeBuf = new StringBuilder();
    private ScheduledFuture<?> bridgePending;
    private volatile boolean running;
    private Thread poller;
    private String lastWarn = "";
    private long lastWarnAt;

    public TelegramBot(CapAI plugin) { this.plugin = plugin; }

    // ---------- config ----------

    private String token() {
        return plugin.getConfig().getString("telegram.bot-token", "").trim();
    }

    public boolean isEnabled() {
        return plugin.getConfig().getBoolean("telegram.enabled", false) && !token().isBlank();
    }

    private List<String> ids(String path) {
        List<String> out = new ArrayList<>();
        List<?> raw = plugin.getConfig().getList(path);
        if (raw != null) for (Object o : raw) out.add(String.valueOf(o).trim());
        return out;
    }

    private String bridgeChat() {
        String id = plugin.getConfig().getString("telegram.bridge.chat-id", "").trim();
        if (id.isEmpty()) {
            List<String> chats = ids("telegram.chat-ids");
            id = chats.isEmpty() ? "" : chats.get(0);
        }
        return id;
    }

    // ---------- yuborish ----------

    public void notify(String text) {
        if (!isEnabled()) return;
        for (String chat : ids("telegram.chat-ids")) queue(chat, text);
    }

    public void notifyConsole(String text) {
        if (!isEnabled()) return;
        for (String chat : ids("telegram.console-chat-ids")) queue(chat, text);
    }

    private void queue(String chat, String text) {
        try {
            sender.execute(() -> post(chat, text, 15));
        } catch (RejectedExecutionException ignored) {
        }
    }

    /** onDisable uchun: bloklovchi yuborish (qisqa timeout). */
    public void notifyBlocking(String text) {
        if (!isEnabled()) return;
        for (String chat : ids("telegram.chat-ids")) post(chat, text, 5);
    }

    /** O'yin chatini Telegram guruhiga (2 soniyalik paketlarda) yuboradi. */
    public synchronized void bridgeSend(String line) {
        if (!isEnabled()) return;
        String chat = bridgeChat();
        if (chat.isEmpty()) return;
        if (bridgeBuf.length() < 3500) bridgeBuf.append(line).append('\n');
        if (bridgePending == null) {
            try {
                bridgePending = sender.schedule(() -> flushBridge(chat), 2, TimeUnit.SECONDS);
            } catch (RejectedExecutionException ignored) {
            }
        }
    }

    private void flushBridge(String chat) {
        String text;
        synchronized (this) {
            text = bridgeBuf.toString().trim();
            bridgeBuf.setLength(0);
            bridgePending = null;
        }
        if (!text.isEmpty()) post(chat, text, 15);
    }

    private void post(String chatId, String text, int timeoutSec) {
        for (String part : split(text)) {
            JsonObject body = new JsonObject();
            body.addProperty("chat_id", chatId);
            body.addProperty("text", part);
            body.addProperty("disable_web_page_preview", true);
            try {
                call("sendMessage", body, timeoutSec);
            } catch (Exception e) {
                warn("Telegram'ga yuborilmadi", e);
            }
        }
    }

    private static List<String> split(String text) {
        List<String> parts = new ArrayList<>();
        String rest = text;
        while (rest.length() > 4000) {
            int cut = rest.lastIndexOf('\n', 4000);
            if (cut < 1) cut = 4000;
            parts.add(rest.substring(0, cut));
            rest = rest.substring(cut).stripLeading();
        }
        if (!rest.isBlank()) parts.add(rest);
        return parts;
    }

    private JsonObject call(String method, JsonObject body, int timeoutSec) throws Exception {
        for (int attempt = 0; ; attempt++) {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create("https://api.telegram.org/bot" + token() + "/" + method))
                    .timeout(Duration.ofSeconds(timeoutSec))
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(body.toString()))
                    .build();
            HttpResponse<String> resp = http.send(request, HttpResponse.BodyHandlers.ofString());
            JsonObject json = JsonParser.parseString(resp.body()).getAsJsonObject();
            if (json.has("ok") && json.get("ok").getAsBoolean()) return json;

            int code = json.has("error_code") ? json.get("error_code").getAsInt() : resp.statusCode();
            if (code == 429 && attempt == 0) {
                long wait = 2;
                if (json.has("parameters") && json.getAsJsonObject("parameters").has("retry_after"))
                    wait = Math.min(10, json.getAsJsonObject("parameters").get("retry_after").getAsLong());
                Thread.sleep(wait * 1000);
                continue;
            }
            String desc = json.has("description") ? json.get("description").getAsString() : "noma'lum xato";
            throw new IllegalStateException("Telegram " + code + ": " + desc);
        }
    }

    private String safe(String s) {
        String t = token();
        if (s == null) return "";
        return t.isEmpty() ? s : s.replace(t, "<TOKEN>");
    }

    private void warn(String what, Exception e) {
        String msg = what + ": " + safe(e.getMessage());
        long now = System.currentTimeMillis();
        if (msg.equals(lastWarn) && now - lastWarnAt < 300_000) return;
        lastWarn = msg;
        lastWarnAt = now;
        plugin.getLogger().warning(msg);
    }

    // ---------- Out (Telegram chatiga natija) ----------

    private final class ChatOut implements Out {
        private final String chatId;
        private final StringBuilder buf = new StringBuilder();
        private ScheduledFuture<?> pendingFlush;

        ChatOut(String chatId) { this.chatId = chatId; }

        @Override
        public void info(String text) { add(COLOR.matcher(text).replaceAll("")); }

        @Override
        public void raw(String text) { add(text); }

        private synchronized void add(String line) {
            if (buf.length() < 20_000) buf.append(line).append('\n');
            if (pendingFlush == null) {
                try {
                    pendingFlush = sender.schedule(this::flush, 600, TimeUnit.MILLISECONDS);
                } catch (RejectedExecutionException ignored) {
                }
            }
        }

        private void flush() {
            String text;
            synchronized (this) {
                text = buf.toString().trim();
                buf.setLength(0);
                pendingFlush = null;
            }
            if (!text.isEmpty()) post(chatId, text, 15);
        }
    }

    public Out chatOut(String chatId) { return new ChatOut(chatId); }

    public Out broadcastOut() {
        List<Out> outs = new ArrayList<>();
        for (String id : ids("telegram.chat-ids")) outs.add(new ChatOut(id));
        return new Out() {
            @Override
            public void info(String text) { for (Out o : outs) o.info(text); }

            @Override
            public void raw(String text) { for (Out o : outs) o.raw(text); }
        };
    }

    // ---------- qabul qilish (long polling) ----------

    public void start() {
        running = true;
        poller = new Thread(this::pollLoop, "CapAI-TG-Poll");
        poller.setDaemon(true);
        poller.start();
    }

    public void stop() {
        running = false;
        if (poller != null) poller.interrupt();
        sender.shutdown();
        try {
            sender.awaitTermination(3, TimeUnit.SECONDS);
        } catch (InterruptedException ignored) {
            Thread.currentThread().interrupt();
        }
    }

    private void pollLoop() {
        long offset = 0;
        boolean init = false;
        while (running) {
            try {
                if (!isEnabled()) {
                    init = false;
                    Thread.sleep(10_000);
                    continue;
                }
                if (!init) {
                    JsonObject b = new JsonObject();
                    b.addProperty("offset", -1);
                    b.addProperty("timeout", 0);
                    JsonArray old = call("getUpdates", b, 15).getAsJsonArray("result");
                    if (old.size() > 0) {
                        offset = old.get(old.size() - 1).getAsJsonObject().get("update_id").getAsLong() + 1;
                    }
                    init = true;
                }

                JsonObject b = new JsonObject();
                b.addProperty("offset", offset);
                b.addProperty("timeout", 25);
                JsonArray updates = call("getUpdates", b, 40).getAsJsonArray("result");
                for (JsonElement el : updates) {
                    JsonObject u = el.getAsJsonObject();
                    offset = Math.max(offset, u.get("update_id").getAsLong() + 1);
                    try {
                        handleUpdate(u);
                    } catch (Exception e) {
                        warn("Telegram buyrug'i xatosi", e);
                    }
                }
            } catch (InterruptedException ie) {
                return;
            } catch (Exception e) {
                warn("Telegram'dan o'qib bo'lmadi", e);
                try {
                    Thread.sleep(5_000);
                } catch (InterruptedException ie) {
                    return;
                }
            }
        }
    }

    private static String displayName(JsonObject msg) {
        if (!msg.has("from")) return "?";
        JsonObject f = msg.getAsJsonObject("from");
        if (f.has("username")) return f.get("username").getAsString();
        if (f.has("first_name")) return f.get("first_name").getAsString();
        return "?";
    }

    private void handleUpdate(JsonObject u) {
        JsonObject msg = u.has("message") ? u.getAsJsonObject("message") : null;
        if (msg == null || !msg.has("text") || !msg.has("chat")) return;

        String text = msg.get("text").getAsString().trim();
        String chatId = String.valueOf(msg.getAsJsonObject("chat").get("id").getAsLong());
        String userId = msg.has("from") ? String.valueOf(msg.getAsJsonObject("from").get("id").getAsLong()) : "";

        if (!text.startsWith("/")) {
            handleBridgeIncoming(chatId, displayName(msg), text);
            return;
        }

        String[] parts = text.split("\\s+", 2);
        String cmd = parts[0].substring(1).toLowerCase(Locale.ROOT);
        int at = cmd.indexOf('@');
        if (at >= 0) cmd = cmd.substring(0, at);
        String arg = parts.length > 1 ? parts[1].trim() : "";

        Out out = chatOut(chatId);

        if (cmd.equals("id")) {
            out.raw("Sizning user ID: " + userId + "\nChat ID: " + chatId);
            return;
        }
        if (!KNOWN.contains(cmd)) return;

        boolean admin = ids("telegram.admin-user-ids").contains(userId);
        boolean console = ids("telegram.console-user-ids").contains(userId)
                && (chatId.equals(userId) || ids("telegram.console-chat-ids").contains(chatId));
        if (!admin && !console) {
            out.raw("Ruxsat yo'q. /id yuboring va user ID'ni config.yml dagi telegram.admin-user-ids ga yozing.");
            return;
        }

        final String sub = cmd;
        final String[] rest = arg.isEmpty() ? new String[0] : arg.split("\\s+");

        switch (sub) {
            case "status", "crash", "check", "ask", "mutes", "unmute" ->
                    plugin.getServer().getScheduler().runTask(plugin,
                            () -> plugin.getAdmin().execute(out, "cap", sub, rest));
            case "players" -> plugin.getServer().getScheduler().runTask(plugin, () -> {
                Collection<? extends Player> ps = Bukkit.getOnlinePlayers();
                if (ps.isEmpty()) {
                    out.raw("Online o'yinchi yo'q.");
                } else {
                    List<String> names = new ArrayList<>();
                    for (Player p : ps) names.add(p.getName());
                    out.raw("Online (" + ps.size() + "): " + String.join(", ", names));
                }
            });
            case "mute" -> muteFromTelegram(out, rest);
            case "kick" -> kickFromTelegram(out, rest);
            case "console", "cmd", "stop", "restart", "forcerestart", "kill", "yes", "no" -> {
                if (!console) {
                    out.raw("Bu buyruq faqat konsol huquqi berilgan shaxsiy chatda ishlaydi (telegram.console-user-ids).");
                } else {
                    handleConsole(out, chatId, userId, sub, arg);
                }
            }
            default -> out.raw("""
                    CapAI buyruqlari:
                    /status - TPS, RAM, dunyolar
                    /crash - oxirgi crashni AI tahlil qiladi
                    /check - serverga nima yetishmayotganini tekshiradi
                    /ask <savol> - server haqida savol
                    /players - online o'yinchilar
                    /mute <ism> <daqiqa> - mute berish
                    /kick <ism> [sabab] - o'yindan chiqarish
                    /mutes | /unmute <ism>

                    Konsol (faqat egasi):
                    /console off|warn|all - konsolni ko'rish
                    /cmd <komanda> - konsolda bajarish
                    /restart | /stop - server (tasdiq bilan)
                    /forcerestart | /kill - panel orqali majburan
                    /yes | /no - tasdiqlash
                    /id - Telegram ID'ingiz""");
        }
    }

    private void muteFromTelegram(Out out, String[] rest) {
        if (rest.length < 2) {
            out.raw("Foydalanish: /mute <ism> <daqiqa>");
            return;
        }
        int minutes;
        try {
            minutes = Integer.parseInt(rest[1]);
        } catch (NumberFormatException e) {
            out.raw("Daqiqa raqam bo'lishi kerak.");
            return;
        }
        if (minutes < 1 || minutes > 43_200) {
            out.raw("Daqiqa 1 dan 43200 gacha bo'lishi kerak.");
            return;
        }
        final int min = minutes;
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            Player p = Bukkit.getPlayerExact(rest[0]);
            if (p == null) {
                out.raw("O'yinchi online emas: " + rest[0]);
                return;
            }
            plugin.getMuteManager().mute(p.getUniqueId(), p.getName(), min);
            p.sendMessage(plugin.msg("prefix") + plugin.msg("muted").replace("%time%", MuteManager.format(min * 60_000L)));
            out.raw("✅ " + p.getName() + " " + min + " daqiqaga mute qilindi.");
        });
    }

    private void kickFromTelegram(Out out, String[] rest) {
        if (rest.length < 1) {
            out.raw("Foydalanish: /kick <ism> [sabab]");
            return;
        }
        String reason = rest.length > 1 ? String.join(" ", Arrays.copyOfRange(rest, 1, rest.length)) : "Admin tomonidan chiqarildi";
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            Player p = Bukkit.getPlayerExact(rest[0]);
            if (p == null) {
                out.raw("O'yinchi online emas: " + rest[0]);
                return;
            }
            p.kick(Component.text(reason));
            out.raw("✅ " + p.getName() + " serverdan chiqarildi.");
        });
    }

    // ---------- konsol ----------

    private void askConfirm(Out out, String userId, String desc, Runnable action) {
        pending.put(userId, new Pending(desc, action, System.currentTimeMillis() + 30_000));
        out.raw("⚠️ Tasdiqlash kerak: " + desc + "\n30 soniya ichida /yes yuboring (bekor qilish: /no).");
    }

    private void handleConsole(Out out, String chatId, String userId, String cmd, String arg) {
        switch (cmd) {
            case "console" -> {
                String mode = arg.toLowerCase(Locale.ROOT);
                if (!mode.equals("off") && !mode.equals("warn") && !mode.equals("all")) {
                    out.raw("Hozirgi rejim: " + plugin.getConsoleMirror().mode() + "\nFoydalanish: /console off|warn|all");
                    return;
                }
                plugin.getConsoleMirror().setMode(mode);
                out.raw("✅ Konsol rejimi: " + mode);
            }
            case "cmd" -> {
                String command = arg.startsWith("/") ? arg.substring(1).trim() : arg;
                if (command.isEmpty()) {
                    out.raw("Foydalanish: /cmd <konsol komandasi>");
                    return;
                }
                String first = command.split("\\s+")[0].toLowerCase(Locale.ROOT);
                int colon = first.indexOf(':');
                if (colon >= 0) first = first.substring(colon + 1);

                Set<String> confirm = new HashSet<>();
                for (String s : plugin.getConfig().getStringList("telegram.confirm-commands")) confirm.add(s.toLowerCase(Locale.ROOT));

                final String finalCommand = command;
                if (confirm.contains(first)) {
                    askConfirm(out, userId, "konsol komandasi: " + command, () -> runConsole(out, chatId, userId, finalCommand));
                } else {
                    runConsole(out, chatId, userId, finalCommand);
                }
            }
            case "stop" -> askConfirm(out, userId, "serverni O'CHIRISH", () -> {
                audit(userId, "server o'chirildi");
                plugin.getPower().stop(out);
            });
            case "restart" -> askConfirm(out, userId, "serverni QAYTA ISHGA TUSHIRISH", () -> {
                audit(userId, "server qayta ishga tushirildi");
                plugin.getPower().restart(out);
            });
            case "forcerestart" -> askConfirm(out, userId, "serverni panel orqali MAJBURAN qayta ishga tushirish", () -> {
                audit(userId, "majburiy restart (panel)");
                plugin.getPower().panelSignal(out, "restart");
            });
            case "kill" -> askConfirm(out, userId, "serverni MAJBURAN to'xtatish (kill)", () -> {
                audit(userId, "majburiy kill (panel)");
                plugin.getPower().panelSignal(out, "kill");
            });
            case "yes" -> {
                Pending p = pending.remove(userId);
                if (p == null || p.expires < System.currentTimeMillis()) {
                    out.raw("Tasdiqlanadigan amal yo'q yoki vaqti o'tgan.");
                } else {
                    p.action.run();
                }
            }
            case "no" -> {
                pending.remove(userId);
                out.raw("Bekor qilindi.");
            }
            default -> {
            }
        }
    }

    private void audit(String userId, String what) {
        plugin.getLogger().warning("Telegram konsol [" + userId + "]: " + what);
        notify("🖥️ Konsol amali (user " + userId + "): " + what);
    }

    private void runConsole(Out out, String chatId, String userId, String command) {
        audit(userId, "/" + command);
        plugin.getConsoleMirror().capture(chatId, 3000);
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            boolean ok = Bukkit.dispatchCommand(Bukkit.getConsoleSender(), command);
            out.raw(ok ? "✅ Bajarildi: " + command : "❌ Komanda topilmadi yoki xato: " + command);
        });
    }

    // ---------- Telegram -> o'yin chat ko'prigi ----------

    private void handleBridgeIncoming(String chatId, String name, String text) {
        FileConfiguration c = plugin.getConfig();
        if (!c.getBoolean("telegram.bridge.enabled", false) || !c.getBoolean("telegram.bridge.tg-to-game", true)) return;
        if (!chatId.equals(bridgeChat())) return;

        String clean = text.replace("§", "").replace('\n', ' ').trim();
        if (clean.length() > 200) clean = clean.substring(0, 200);
        if (clean.isEmpty()) return;
        final String message = clean;

        if (plugin.getAdGuard().isAd(message) || plugin.getChatFilter().isSwear(message)) {
            chatOut(chatId).raw("⚠️ Xabar filtrdan o'tmadi va o'yinga yuborilmadi.");
            return;
        }

        String fmt = plugin.color(c.getString("telegram.bridge.game-format", "&9[TG] &f%name%&7: &f%message%"));
        String line = fmt.replace("%name%", name.replace("§", "")).replace("%message%", message);
        plugin.getServer().getScheduler().runTask(plugin, () -> Bukkit.broadcastMessage(line));
    }
}
