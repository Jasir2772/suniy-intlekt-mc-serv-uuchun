package uz.capmine.capai;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

/** O'yin chatini Telegram guruhiga yuboradi (Telegram -> o'yin TelegramBot ichida). */
public final class ChatBridge implements Listener {
    private final CapAI plugin;

    public ChatBridge(CapAI plugin) { this.plugin = plugin; }

    private boolean gameToTg() {
        FileConfiguration c = plugin.getConfig();
        return c.getBoolean("telegram.bridge.enabled", false) && c.getBoolean("telegram.bridge.game-to-tg", true);
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onChat(AsyncChatEvent event) {
        if (!gameToTg()) return;
        String text = PlainTextComponentSerializer.plainText().serialize(event.message()).trim();
        if (text.isEmpty()) return;
        String fmt = plugin.getConfig().getString("telegram.bridge.tg-format", "👤 %name%: %message%");
        plugin.getTelegram().bridgeSend(fmt.replace("%name%", event.getPlayer().getName()).replace("%message%", text));
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onJoin(PlayerJoinEvent event) {
        if (gameToTg() && plugin.getConfig().getBoolean("telegram.bridge.join-quit", true)) {
            plugin.getTelegram().bridgeSend("➕ " + event.getPlayer().getName() + " serverga kirdi");
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent event) {
        if (gameToTg() && plugin.getConfig().getBoolean("telegram.bridge.join-quit", true)) {
            plugin.getTelegram().bridgeSend("➖ " + event.getPlayer().getName() + " serverdan chiqdi");
        }
    }
}
