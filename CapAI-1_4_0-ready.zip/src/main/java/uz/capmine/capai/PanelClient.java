package uz.capmine.capai;

import org.bukkit.configuration.file.FileConfiguration;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;

/** Pterodactyl uslubidagi hosting paneli API'si orqali server quvvatini boshqaradi. */
public final class PanelClient {
    private final CapAI plugin;
    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build();

    public PanelClient(CapAI plugin) { this.plugin = plugin; }

    public boolean isEnabled() {
        FileConfiguration c = plugin.getConfig();
        return c.getBoolean("telegram.panel.enabled", false)
                && !c.getString("telegram.panel.url", "").isBlank()
                && !c.getString("telegram.panel.server-id", "").isBlank()
                && !c.getString("telegram.panel.api-key", "").isBlank();
    }

    /** signal: start, stop, restart yoki kill */
    public void power(String signal) throws Exception {
        FileConfiguration c = plugin.getConfig();
        String base = c.getString("telegram.panel.url", "").trim();
        if (base.endsWith("/")) base = base.substring(0, base.length() - 1);
        String id = c.getString("telegram.panel.server-id", "").trim();
        String key = c.getString("telegram.panel.api-key", "").trim();

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(base + "/api/client/servers/" + id + "/power"))
                .timeout(Duration.ofSeconds(15))
                .header("Authorization", "Bearer " + key)
                .header("Accept", "application/json")
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString("{\"signal\":\"" + signal + "\"}"))
                .build();
        HttpResponse<String> resp = http.send(request, HttpResponse.BodyHandlers.ofString());
        if (resp.statusCode() < 200 || resp.statusCode() >= 300) {
            String body = resp.body() == null ? "" : resp.body();
            if (body.length() > 200) body = body.substring(0, 200);
            throw new IllegalStateException("Panel HTTP " + resp.statusCode() + ": " + body);
        }
    }
}
