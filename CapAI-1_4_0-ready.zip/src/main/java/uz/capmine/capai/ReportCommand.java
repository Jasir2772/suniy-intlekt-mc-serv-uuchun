package uz.capmine.capai;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardOpenOption;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** /report <o'yinchi> <sabab>: adminlarga va Telegram'ga shikoyat yuboradi. */
public final class ReportCommand implements CommandExecutor, TabCompleter {
    private final CapAI plugin;
    private final Map<UUID, Long> last = new ConcurrentHashMap<>();

    public ReportCommand(CapAI plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        String prefix = plugin.msg("prefix");
        if (!(sender instanceof Player player)) {
            sender.sendMessage(prefix + plugin.msg("only-player"));
            return true;
        }
        if (args.length < 2) {
            player.sendMessage(prefix + plugin.msg("report-usage"));
            return true;
        }

        String target = args[0];
        if (target.equalsIgnoreCase(player.getName())) {
            player.sendMessage(prefix + plugin.msg("report-self"));
            return true;
        }

        long cooldownMs = plugin.getConfig().getLong("report.cooldown-seconds", 60) * 1000L;
        Long prev = last.get(player.getUniqueId());
        long now = System.currentTimeMillis();
        if (prev != null && now - prev < cooldownMs) {
            long left = (cooldownMs - (now - prev) + 999) / 1000;
            player.sendMessage(prefix + plugin.msg("report-cooldown").replace("%seconds%", String.valueOf(left)));
            return true;
        }

        String reason = String.join(" ", Arrays.copyOfRange(args, 1, args.length)).replace("§", "").trim();
        if (reason.length() < 3) {
            player.sendMessage(prefix + plugin.msg("report-usage"));
            return true;
        }
        if (reason.length() > 200) reason = reason.substring(0, 200);
        last.put(player.getUniqueId(), now);

        Player tp = Bukkit.getPlayerExact(target);
        String targetName = tp != null ? tp.getName() : target;
        String from = player.getName();
        String finalReason = reason;

        plugin.getStats().onReport();
        player.sendMessage(prefix + plugin.msg("report-sent"));

        String note = plugin.msg("report-notify")
                .replace("%from%", from)
                .replace("%target%", targetName)
                .replace("%reason%", finalReason);
        for (Player staff : Bukkit.getOnlinePlayers()) {
            if (staff.hasPermission("capai.notify")) staff.sendMessage(note);
        }

        plugin.getTelegram().notify("📢 Shikoyat\nKimdan: " + from + "\nKimga: " + targetName
                + (tp != null ? " (online)" : " (offline)") + "\nSabab: " + finalReason
                + (tp != null ? "\nMute: /mute " + targetName + " 30" : ""));

        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                Path file = plugin.getDataFolder().toPath().resolve("reports.log");
                Files.writeString(file, LocalDateTime.now() + " | " + from + " -> " + targetName + " | " + finalReason + "\n",
                        StandardCharsets.UTF_8, StandardOpenOption.CREATE, StandardOpenOption.APPEND);
            } catch (IOException ignored) {
            }
        });
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            String typed = args[0].toLowerCase(Locale.ROOT);
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.getName().toLowerCase(Locale.ROOT).startsWith(typed)) out.add(p.getName());
            }
        }
        return out;
    }
}
