package uz.capmine.capai;

import org.bukkit.configuration.file.FileConfiguration;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public final class TimeUtil {
    private TimeUtil() {}

    public static ZoneId zone(FileConfiguration c) {
        try {
            return ZoneId.of(c.getString("settings.timezone", "Asia/Tashkent"));
        } catch (Exception e) {
            return ZoneId.systemDefault();
        }
    }

    public static ZonedDateTime now(FileConfiguration c) { return ZonedDateTime.now(zone(c)); }

    public static LocalDate today(FileConfiguration c) { return now(c).toLocalDate(); }
}
