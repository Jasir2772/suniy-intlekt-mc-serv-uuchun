package uz.capmine.capai;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;

import java.util.Locale;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** Chatdagi savollarga server ma'lumotiga tayanib AI javob beradi (faqat o'sha o'yinchiga). */
public final class AutoAnswer implements Listener {
    private final CapAI plugin;
    private final Map<UUID, Long> lastByPlayer = new ConcurrentHashMap<>();
    private volatile long lastGlobal;

    public AutoAnswer(CapAI plugin) { this.plugin = plugin; }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onChat(AsyncChatEvent event) {
        FileConfiguration c = plugin.getConfig();
        if (!c.getBoolean("autoanswer.enabled", false)) return;
        if (plugin.getAIClient().getApiKey().isBlank()) return;

        String text = PlainTextComponentSerializer.plainText().serialize(event.message()).trim();
        if (text.length() < 6 || text.length() > 200) return;
        if (c.getBoolean("autoanswer.require-question-mark", true) && !text.contains("?")) return;

        String lower = text.toLowerCase(Locale.ROOT);
        boolean hit = false;
        for (String t : c.getStringList("autoanswer.triggers")) {
            if (!t.isBlank() && lower.contains(t.toLowerCase(Locale.ROOT))) {
                hit = true;
                break;
            }
        }
        if (!hit) return;

        Player p = event.getPlayer();
        UUID id = p.getUniqueId();
        long now = System.currentTimeMillis();
        Long prev = lastByPlayer.get(id);
        if (prev != null && now - prev < c.getLong("autoanswer.player-cooldown-seconds", 60) * 1000L) return;
        if (now - lastGlobal < c.getLong("autoanswer.global-cooldown-seconds", 8) * 1000L) return;
        lastByPlayer.put(id, now);
        lastGlobal = now;

        String serverInfo = c.getString("settings.server-info", "").trim();
        String system = """
                Sen CapMine Minecraft serverining yordamchisisan. O'yinchi chatda savol berdi.
                Faqat quyidagi server ma'lumotiga tayanib, 1-2 qisqa gapda o'zbekcha javob ber.
                Javob ma'lumotda bo'lmasa, aynan SKIP deb yoz va boshqa hech narsa yozma.
                Server ma'lumoti:
                %s
                """.formatted(serverInfo);
        String model = c.getString("api.model", "gpt-4o-mini");
        int timeout = c.getInt("settings.timeout-seconds", 20);
        String question = text;

        plugin.getStats().onAiQuestion();
        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
            try {
                String reply = plugin.getAIClient().complete(system, question, model, 150, timeout).trim();
                if (reply.isEmpty() || reply.toUpperCase(Locale.ROOT).startsWith("SKIP")) return;
                if (reply.length() > 300) reply = reply.substring(0, 300) + "...";
                final String out = reply.replace("§", "");
                if (!plugin.isEnabled()) return;
                plugin.getServer().getScheduler().runTask(plugin, () -> {
                    if (p.isOnline()) p.sendMessage(plugin.msg("prefix") + out);
                });
            } catch (Exception e) {
                plugin.getLogger().warning("AutoAnswer xatosi: " + ServerInspector.redact(String.valueOf(e.getMessage())));
            }
        });
    }
}
