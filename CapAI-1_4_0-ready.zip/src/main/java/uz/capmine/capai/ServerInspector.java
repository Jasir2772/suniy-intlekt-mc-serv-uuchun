package uz.capmine.capai;

import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.plugin.Plugin;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.lang.management.ManagementFactory;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.Deque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.function.Predicate;
import java.util.regex.Pattern;
import java.util.zip.GZIPInputStream;

/** Server holati va loglarni AI uchun yig'adi (IP va parollar yashiriladi). */
public final class ServerInspector {
    private static final Pattern IPV4 = Pattern.compile("\\b(?:\\d{1,3}\\.){3}\\d{1,3}\\b");
    private static final Pattern SECRET = Pattern.compile("(?i)(password|passwd|token|secret|api[-_ ]?key)(\\s*[=:]\\s*)\\S+");
    private static final Pattern SK_KEY = Pattern.compile("sk-[A-Za-z0-9_\\-]{6,}");
    private static final Pattern TG_TOKEN = Pattern.compile("\\b\\d{6,}:[A-Za-z0-9_-]{30,}");
    private static final Pattern AUTH_CMD = Pattern.compile(
            "(?i)(issued server command: /?(?:login|l|log|reg|register|changepassword|changepass|cp|unregister|authme:[a-z]+)) .*");
    private static final Pattern PANEL_KEY = Pattern.compile("\\bptl[a-z]_[A-Za-z0-9]{20,}");
    private static final Pattern ANSI = Pattern.compile("\\u001B\\[[;\\d]*m");
    private static final Pattern KEYWORDS = Pattern.compile(
            "ERROR|WARN|SEVERE|Exception|Caused by|OutOfMemory|Can't keep up|stopped responding|Watchdog"
                    + "|Could not pass event|Failed to|Error occurred|StackOverflow|NoClassDefFound|ClassNotFound"
                    + "|UnsupportedClassVersion|Unsupported API|Ambiguous plugin|Could not load|Encountered an unexpected",
            Pattern.CASE_INSENSITIVE);

    private static final List<String> SAFE_PROPS = List.of(
            "view-distance", "simulation-distance", "max-players", "online-mode", "network-compression-threshold",
            "max-tick-time", "sync-chunk-writes", "entity-broadcast-range-percentage", "spawn-protection",
            "allow-flight", "difficulty", "enforce-whitelist", "white-list", "level-type", "max-world-size");

    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

    private ServerInspector() {}

    /** IP manzillar, parollar va API kalitlarni yashiradi. */
    public static String redact(String s) {
        s = SK_KEY.matcher(s).replaceAll("<KEY>");
        s = TG_TOKEN.matcher(s).replaceAll("<TOKEN>");
        s = PANEL_KEY.matcher(s).replaceAll("<KEY>");
        s = AUTH_CMD.matcher(s).replaceAll("$1 <HIDDEN>");
        s = SECRET.matcher(s).replaceAll("$1$2<REDACTED>");
        s = IPV4.matcher(s).replaceAll("x.x.x.x");
        return s;
    }

    /** Asosiy oqimda chaqirilishi kerak (Bukkit API). */
    public static String snapshot(CapAI plugin) {
        StringBuilder sb = new StringBuilder();
        Runtime rt = Runtime.getRuntime();

        sb.append("Hozirgi vaqt: ").append(java.time.LocalDateTime.now().format(FMT)).append('\n');
        sb.append("Server: ").append(Bukkit.getVersion()).append('\n');
        sb.append("API: ").append(Bukkit.getBukkitVersion()).append('\n');
        sb.append("Java: ").append(System.getProperty("java.version")).append(" (")
                .append(System.getProperty("java.vm.name")).append(")\n");
        sb.append("OS: ").append(System.getProperty("os.name")).append(' ').append(System.getProperty("os.arch")).append('\n');
        sb.append("CPU yadrolar: ").append(rt.availableProcessors()).append('\n');
        sb.append("RAM: ishlatilmoqda ").append((rt.totalMemory() - rt.freeMemory()) >> 20)
                .append(" MB, JVM maksimum ").append(rt.maxMemory() >> 20).append(" MB\n");
        sb.append("Diskda bo'sh joy: ").append(new File(".").getFreeSpace() >> 30).append(" GB\n");

        long upMin = ManagementFactory.getRuntimeMXBean().getUptime() / 60_000;
        sb.append("Ishlash vaqti: ").append(upMin / 60).append(" soat ").append(upMin % 60).append(" daqiqa\n");

        String jvmArgs = String.join(" ", ManagementFactory.getRuntimeMXBean().getInputArguments());
        if (jvmArgs.length() > 700) jvmArgs = jvmArgs.substring(0, 700) + "...";
        sb.append("JVM flaglar: ").append(jvmArgs.isEmpty() ? "(yo'q)" : jvmArgs).append('\n');

        try {
            double[] tps = Bukkit.getTPS();
            sb.append(String.format(java.util.Locale.ROOT, "TPS (1/5/15 daq): %.1f / %.1f / %.1f\n",
                    Math.min(20, tps[0]), Math.min(20, tps[1]), Math.min(20, tps[2])));
            sb.append(String.format(java.util.Locale.ROOT, "MSPT: %.1f ms\n", Bukkit.getAverageTickTime()));
        } catch (Throwable ignored) {
        }

        sb.append("Online: ").append(Bukkit.getOnlinePlayers().size()).append('/').append(Bukkit.getMaxPlayers()).append('\n');

        for (World w : Bukkit.getWorlds()) {
            sb.append("Dunyo ").append(w.getName()).append(" (").append(w.getEnvironment()).append("): chunk ")
                    .append(w.getLoadedChunks().length).append(", entity ").append(w.getEntities().size())
                    .append(", o'yinchi ").append(w.getPlayers().size()).append('\n');
        }

        Plugin[] plugins = Bukkit.getPluginManager().getPlugins();
        sb.append("Pluginlar (").append(plugins.length).append("):\n");
        for (Plugin p : plugins) {
            sb.append("- ").append(p.getName()).append(' ').append(p.getDescription().getVersion());
            if (!p.isEnabled()) sb.append(" [O'CHIRILGAN]");
            sb.append('\n');
        }

        Properties props = new Properties();
        try (FileInputStream in = new FileInputStream("server.properties")) {
            props.load(in);
            sb.append("server.properties:\n");
            for (String key : SAFE_PROPS) {
                if (props.containsKey(key)) sb.append("  ").append(key).append('=').append(props.getProperty(key)).append('\n');
            }
        } catch (IOException ignored) {
        }

        return sb.toString();
    }

    /** Fayllarni o'qiydi: asinxron oqimda chaqiring. */
    public static String logContext(boolean full, int maxChars) {
        StringBuilder sb = new StringBuilder();

        if (full) {
            File crash = newest(new File("crash-reports"), n -> n.endsWith(".txt"));
            if (crash != null) {
                try {
                    sb.append("\n=== SO'NGGI CRASH REPORT (").append(stamp(crash)).append(") ===\n")
                            .append(readHead(crash, maxChars * 35 / 100)).append('\n');
                } catch (IOException ignored) {
                }
            }
            File hs = newest(new File("."), n -> n.startsWith("hs_err_pid") && n.endsWith(".log"));
            if (hs != null) {
                try {
                    sb.append("\n=== JVM CRASH (hs_err) (").append(stamp(hs)).append(") ===\n")
                            .append(readHead(hs, maxChars * 15 / 100)).append('\n');
                } catch (IOException ignored) {
                }
            }
            File prev = newest(new File("logs"), n -> n.endsWith(".log.gz"));
            if (prev != null) {
                try {
                    sb.append("\n=== OLDINGI SESSIYA LOGI (").append(stamp(prev)).append(") ===\n")
                            .append(summarize(tailLines(prev, 4000), maxChars * 25 / 100)).append('\n');
                } catch (IOException ignored) {
                }
            }
        }

        File latest = new File("logs/latest.log");
        if (latest.exists()) {
            int share = full ? maxChars * 25 / 100 : maxChars;
            try {
                sb.append("\n=== HOZIRGI LOG (latest.log) ===\n")
                        .append(summarize(tailLines(latest, 4000), share)).append('\n');
            } catch (IOException ignored) {
            }
        }

        if (sb.length() == 0) sb.append("\n(Log va crash fayllar topilmadi.)\n");
        return sb.toString();
    }

    private static String stamp(File f) {
        return FMT.format(Instant.ofEpochMilli(f.lastModified()).atZone(ZoneId.systemDefault()));
    }

    private static File newest(File dir, Predicate<String> filter) {
        File[] files = dir.listFiles((d, n) -> filter.test(n));
        if (files == null || files.length == 0) return null;
        return Arrays.stream(files).max(Comparator.comparingLong(File::lastModified)).orElse(null);
    }

    private static String readHead(File f, int max) throws IOException {
        StringBuilder sb = new StringBuilder();
        try (Reader r = new InputStreamReader(new FileInputStream(f), StandardCharsets.UTF_8)) {
            char[] buf = new char[2048];
            int n;
            while (sb.length() < max && (n = r.read(buf)) != -1) sb.append(buf, 0, n);
        }
        if (sb.length() > max) sb.setLength(max);
        return sb.toString();
    }

    private static List<String> tailLines(File f, int maxLines) throws IOException {
        boolean gz = f.getName().endsWith(".gz");
        Deque<String> dq = new ArrayDeque<>();
        try (InputStream raw = new FileInputStream(f);
             InputStream in = gz ? new GZIPInputStream(raw) : raw;
             BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) {
                dq.addLast(line);
                if (dq.size() > maxLines) dq.removeFirst();
            }
        }
        return new ArrayList<>(dq);
    }

    private static String summarize(List<String> lines, int maxChars) {
        StringBuilder errors = new StringBuilder();
        Map<String, Integer> seen = new HashMap<>();
        int atBudget = 0;

        for (String raw : lines) {
            String line = ANSI.matcher(raw).replaceAll("");
            boolean isAt = line.startsWith("\tat ") || line.startsWith("    at ") || line.startsWith("\t... ");
            if (isAt) {
                if (atBudget > 0) {
                    errors.append(line).append('\n');
                    atBudget--;
                }
                continue;
            }
            if (KEYWORDS.matcher(line).find()) {
                String key = line.replaceFirst("^\\[\\d\\d:\\d\\d:\\d\\d] ?", "");
                int count = seen.merge(key, 1, Integer::sum);
                if (count > 3) {
                    atBudget = 0;
                    continue;
                }
                errors.append(line).append('\n');
                atBudget = 8;
            } else {
                atBudget = 0;
            }
        }

        StringBuilder tail = new StringBuilder();
        for (int i = Math.max(0, lines.size() - 40); i < lines.size(); i++) {
            tail.append(ANSI.matcher(lines.get(i)).replaceAll("")).append('\n');
        }

        return "-- Xato/ogohlantirish qatorlari --\n" + lastChars(errors.toString(), maxChars * 70 / 100)
                + "-- Logning oxirgi 40 qatori --\n" + lastChars(tail.toString(), maxChars * 30 / 100);
    }

    private static String lastChars(String s, int n) {
        if (s.length() <= n) return s;
        return "...\n" + s.substring(s.length() - n);
    }
}
