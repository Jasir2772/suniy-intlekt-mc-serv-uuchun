package uz.capmine.capai;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/** So'kinish, spam/flood va CAPS filtri. */
public final class ChatFilter implements Listener {
    private static final Map<Character, Character> MAP = buildMap();

    private static final class State {
        final Deque<Long> times = new ArrayDeque<>();
        String last = "";
        long lastAt;
        int strikes;
        long lastStrikeAt;
    }

    private final CapAI plugin;
    private volatile Set<String> words = Set.of();
    private volatile List<String> stems = List.of();
    private volatile Set<String> whitelist = Set.of();
    private final Map<UUID, State> states = new ConcurrentHashMap<>();

    public ChatFilter(CapAI plugin) {
        this.plugin = plugin;
        reload();
    }

    private static Map<Character, Character> buildMap() {
        Map<Character, Character> m = new HashMap<>();
        String cyr = "абвгдеёжзийклмнопрстуфхцчшщыэюяўқғҳ";
        String lat = "abvgdeejziiklmnoprstufxscssieuaukgx";
        for (int i = 0; i < cyr.length(); i++) m.put(cyr.charAt(i), lat.charAt(i));
        m.put('ъ', '\0');
        m.put('ь', '\0');
        m.put('y', 'i');
        m.put('h', 'x');
        m.put('w', 'v');
        m.put('q', 'k');
        // 0->o 1->i 3->e 4->a 5->s 6->g 7->t 8->b @->a $->s
        char[] from = {'0', '1', '3', '4', '5', '6', '7', '8', '@', '$'};
        char[] to = {'o', 'i', 'e', 'a', 's', 'g', 't', 'b', 'a', 's'};
        for (int i = 0; i < from.length; i++) m.put(from[i], to[i]);
        return m;
    }

    static String normalize(String s) {
        StringBuilder sb = new StringBuilder();
        for (char raw : s.toLowerCase(Locale.ROOT).toCharArray()) {
            char ch = raw;
            Character mapped = MAP.get(ch);
            if (mapped != null) ch = mapped;
            if (ch == '\0') continue;
            if (Character.isLetter(ch)) {
                if (sb.length() == 0 || sb.charAt(sb.length() - 1) != ch) sb.append(ch);
            } else if (ch == '*' || ch == '.' || ch == '-' || ch == '_' || ch == '\'' || ch == '`'
                    || ch == '\u02BB' || ch == '\u02BC' || ch == '\u2019' || ch == '\u2018') {
                // so'z ichidagi belgilar e'tiborsiz qoldiriladi
            } else {
                if (sb.length() > 0 && sb.charAt(sb.length() - 1) != ' ') sb.append(' ');
            }
        }
        return sb.toString().trim();
    }

    public void reload() {
        FileConfiguration c = plugin.getConfig();
        Set<String> w = new HashSet<>();
        for (String s : c.getStringList("chatfilter.swear.words")) {
            String n = normalize(s);
            if (!n.isEmpty()) w.add(n);
        }
        List<String> st = new ArrayList<>();
        for (String s : c.getStringList("chatfilter.swear.stems")) {
            String n = normalize(s);
            if (!n.isEmpty()) st.add(n);
        }
        Set<String> wl = new HashSet<>();
        for (String s : c.getStringList("chatfilter.swear.whitelist")) {
            String n = normalize(s);
            if (!n.isEmpty()) wl.add(n);
        }
        words = w;
        stems = st;
        whitelist = wl;
    }

    public boolean isSwear(String text) {
        if (!plugin.getConfig().getBoolean("chatfilter.swear.enabled", true)) return false;
        String n = normalize(text);
        for (String token : n.split(" ")) {
            if (token.isEmpty() || whitelist.contains(token)) continue;
            if (words.contains(token)) return true;
            for (String stem : stems) {
                if (token.contains(stem)) return true;
            }
        }
        return false;
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        states.remove(event.getPlayer().getUniqueId());
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onChat(AsyncChatEvent event) {
        FileConfiguration c = plugin.getConfig();
        if (!c.getBoolean("chatfilter.enabled", true)) return;

        Player p = event.getPlayer();
        if (p.hasPermission("capai.filterbypass")) return;
        UUID id = p.getUniqueId();

        if (c.getBoolean("adguard.internal-mute", true)) {
            long rem = plugin.getMuteManager().remaining(id);
            if (rem > 0) {
                event.setCancelled(true);
                p.sendMessage(plugin.msg("prefix") + plugin.msg("muted")
                        .replace("%time%", MuteManager.format(rem)));
                return;
            }
        }

        String text = PlainTextComponentSerializer.plainText().serialize(event.message());
        plugin.getStats().onChat();

        if (isSwear(text)) {
            event.setCancelled(true);
            punishSwear(p, text);
            return;
        }

        String spam = checkSpam(p, text);
        if (spam != null) {
            event.setCancelled(true);
            return;
        }

        if (c.getBoolean("chatfilter.caps.enabled", true) && isCaps(text)) {
            event.message(Component.text(text.toLowerCase(Locale.ROOT)));
        }
    }

    private boolean isCaps(String text) {
        FileConfiguration c = plugin.getConfig();
        int min = c.getInt("chatfilter.caps.min-length", 8);
        int percent = c.getInt("chatfilter.caps.percent", 70);
        int letters = 0;
        int upper = 0;
        for (char ch : text.toCharArray()) {
            if (Character.isLetter(ch)) {
                letters++;
                if (Character.isUpperCase(ch)) upper++;
            }
        }
        return letters >= min && upper * 100 / letters >= percent;
    }

    /** null = hammasi joyida; aks holda xabar bloklanadi. */
    private String checkSpam(Player p, String text) {
        FileConfiguration c = plugin.getConfig();
        State s = states.computeIfAbsent(p.getUniqueId(), k -> new State());
        boolean violation = false;
        boolean doMute = false;
        int muteMinutes = c.getInt("chatfilter.spam-mute-minutes", 5);

        synchronized (s) {
            long now = System.currentTimeMillis();
            long window = c.getInt("chatfilter.flood.window-seconds", 6) * 1000L;
            int max = c.getInt("chatfilter.flood.max-messages", 5);
            while (!s.times.isEmpty() && now - s.times.peekFirst() > window) s.times.pollFirst();

            String norm = text.toLowerCase(Locale.ROOT).replaceAll("\\s+", " ").trim();
            long repeatMs = c.getInt("chatfilter.repeat-seconds", 15) * 1000L;

            if (max > 0 && s.times.size() >= max) violation = true;
            else if (repeatMs > 0 && norm.equals(s.last) && now - s.lastAt < repeatMs) violation = true;

            if (violation) {
                if (now - s.lastStrikeAt > 120_000L) s.strikes = 0;
                s.strikes++;
                s.lastStrikeAt = now;
                int limit = c.getInt("chatfilter.spam-strikes-before-mute", 3);
                if (limit > 0 && s.strikes >= limit) {
                    doMute = true;
                    s.strikes = 0;
                }
            } else {
                s.times.addLast(now);
                s.last = norm;
                s.lastAt = now;
            }
        }

        if (!violation) return null;

        if (doMute) {
            plugin.getMuteManager().mute(p.getUniqueId(), p.getName(), muteMinutes);
            p.sendMessage(plugin.msg("prefix") + plugin.msg("spam-muted").replace("%minutes%", String.valueOf(muteMinutes)));
        } else {
            p.sendMessage(plugin.msg("prefix") + plugin.msg("spam-warn"));
        }
        return "spam";
    }

    private void punishSwear(Player p, String text) {
        FileConfiguration c = plugin.getConfig();
        String name = p.getName();
        int minutes = plugin.getMuteManager().punish(p.getUniqueId(), name,
                c.getIntegerList("chatfilter.swear.mute-minutes"),
                c.getInt("adguard.strike-reset-days", 14));
        plugin.getStats().onSwearMute();

        String shown = text.length() > 120 ? text.substring(0, 120) + "..." : text;
        plugin.getLogger().warning("So'kinish: " + name + " -> \"" + shown + "\" | mute: " + minutes + " daqiqa");

        plugin.getServer().getScheduler().runTask(plugin, () -> {
            if (p.isOnline()) {
                p.sendMessage(plugin.msg("prefix") + plugin.msg("swear-warn")
                        .replace("%minutes%", String.valueOf(minutes)));
            }
            if (c.getBoolean("telegram.notify-filter-mutes", true)) {
                plugin.getTelegram().notify("🤬 So'kinish filtri\nO'yinchi: " + name + "\nXabar: " + shown
                        + "\nJazo: " + minutes + " daqiqa mute (avtomatik)");
            }
            String note = plugin.msg("swear-notify")
                    .replace("%player%", name)
                    .replace("%minutes%", String.valueOf(minutes))
                    .replace("%message%", shown.replace("§", ""));
            for (Player staff : Bukkit.getOnlinePlayers()) {
                if (staff.hasPermission("capai.notify")) staff.sendMessage(note);
            }
        });
    }
}
