package uz.capmine.capai;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class AICommand implements CommandExecutor, TabCompleter {
    private final CapAI plugin;
    private final Set<UUID> busy = ConcurrentHashMap.newKeySet();

    public AICommand(CapAI plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        FileConfiguration cfg = plugin.getConfig();
        String prefix = msg("prefix");

        // /ai reload (konsoldan ham ishlaydi)
        if (args.length >= 1 && args[0].equalsIgnoreCase("reload")) {
            if (!sender.hasPermission("capai.admin")) {
                sender.sendMessage(prefix + msg("no-permission"));
                return true;
            }
            plugin.reloadAll();
            sender.sendMessage(prefix + msg("reloaded"));
            return true;
        }

        if (!(sender instanceof Player player)) {
            sender.sendMessage(prefix + msg("only-player"));
            return true;
        }
        if (!player.hasPermission("capai.use")) {
            player.sendMessage(prefix + msg("no-permission"));
            return true;
        }
        if (args.length == 0) {
            player.sendMessage(prefix + msg("usage"));
            return true;
        }

        UUID uuid = player.getUniqueId();
        boolean unlimited = player.hasPermission("capai.unlimited");
        int dailyLimit = cfg.getInt("settings.daily-limit", 20);
        boolean limited = !unlimited && dailyLimit >= 0;

        // /ai limit
        if (args.length == 1 && args[0].equalsIgnoreCase("limit")) {
            if (!limited) {
                player.sendMessage(prefix + msg("limit-unlimited"));
            } else {
                int left = Math.max(0, dailyLimit - plugin.getUsageManager().used(uuid));
                player.sendMessage(prefix + msg("limit-info")
                        .replace("%left%", String.valueOf(left))
                        .replace("%limit%", String.valueOf(dailyLimit)));
            }
            return true;
        }

        String question = String.join(" ", args).trim();
        int maxLength = cfg.getInt("settings.max-question-length", 300);
        if (question.length() > maxLength) {
            player.sendMessage(prefix + msg("too-long"));
            return true;
        }

        if (plugin.getAIClient().getApiKey().isBlank()) {
            player.sendMessage(prefix + msg("no-key"));
            return true;
        }

        boolean useCooldown = !player.hasPermission("capai.bypass");
        if (useCooldown) {
            long remaining = plugin.getCooldownManager().remaining(uuid, cfg.getLong("settings.cooldown-seconds", 5));
            if (remaining > 0) {
                player.sendMessage(prefix + msg("cooldown").replace("%seconds%", String.valueOf(remaining)));
                return true;
            }
        }

        if (limited && plugin.getUsageManager().used(uuid) >= dailyLimit) {
            player.sendMessage(prefix + msg("limit-reached").replace("%limit%", String.valueOf(dailyLimit)));
            return true;
        }

        if (!busy.add(uuid)) {
            player.sendMessage(prefix + msg("busy"));
            return true;
        }

        // Hamma tekshiruvdan o'tdi: cooldown va limitni hisoblaymiz
        if (useCooldown) plugin.getCooldownManager().mark(uuid);
        if (limited) plugin.getUsageManager().increment(uuid);

        plugin.getStats().onAiQuestion();
        player.sendMessage(prefix + msg("thinking"));

        final String name = player.getName();
        final List<String[]> history = plugin.getChatHistory().get(uuid);
        final int historySize = cfg.getInt("settings.history-size", 3);

        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
            String answer = null;
            boolean success = true;
            try {
                answer = plugin.getAIClient().ask(name, question, history);
            } catch (Exception e) {
                success = false;
                plugin.getLogger().warning("CapAI error: " + e.getMessage());
            }

            final String result = answer;
            final boolean ok = success;
            if (!plugin.isEnabled()) return;
            plugin.getServer().getScheduler().runTask(plugin, () -> {
                busy.remove(uuid);
                if (!ok) {
                    if (limited) plugin.getUsageManager().refund(uuid);
                    if (player.isOnline()) player.sendMessage(msg("prefix") + msg("error"));
                    return;
                }
                plugin.getChatHistory().add(uuid, question, result, historySize);
                if (player.isOnline()) sendWrapped(player, result);
            });
        });
        return true;
    }

    private void sendWrapped(Player player, String text) {
        String prefix = msg("prefix");
        int max = plugin.getConfig().getInt("settings.max-answer-length", 1200);
        if (text.length() > max) text = text.substring(0, max) + "...";
        for (String line : text.split("\\R")) {
            if (line.isBlank()) continue;
            // AI javobiga rang kodlari qo'llanmaydi: faqat prefix rangli
            player.sendMessage(prefix + line.replace("§", ""));
        }
    }

    private String msg(String key) {
        String text = plugin.getConfig().getString("messages." + key, "");
        return ChatColor.translateAlternateColorCodes('&', text);
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length != 1) return List.of();
        List<String> out = new ArrayList<>();
        String typed = args[0].toLowerCase(Locale.ROOT);
        if ("limit".startsWith(typed)) out.add("limit");
        if (sender.hasPermission("capai.admin") && "reload".startsWith(typed)) out.add("reload");
        return out;
    }
}
