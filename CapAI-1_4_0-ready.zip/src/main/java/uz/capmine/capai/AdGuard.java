package uz.capmine.capai;

import io.papermc.paper.event.player.AsyncChatEvent;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;

import java.util.HashSet;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;

/** Boshqa serverlarga reklama qilgan o'yinchini avtomatik mute qiladi. */
public final class AdGuard implements Listener {
    private final CapAI plugin;
    private volatile AdDetector detector;
    private volatile Set<String> monitored;

    public AdGuard(CapAI plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        FileConfiguration c = plugin.getConfig();
        detector = new AdDetector(
                c.getStringList("adguard.allowed-domains"),
                c.getStringList("adguard.allowed-ips"),
                c.getStringList("adguard.suspicious-phrases"));
        Set<String> set = new HashSet<>();
        for (String s : c.getStringList("adguard.monitored-commands")) set.add(s.toLowerCase(Locale.ROOT));
        monitored = set;
    }

    public boolean isAd(String text) {
        return detector.check(text) != null;
    }

    private boolean enabled() {
        return plugin.getConfig().getBoolean("adguard.enabled", true);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onChat(AsyncChatEvent event) {
        if (!enabled()) return;
        String text = PlainTextComponentSerializer.plainText().serialize(event.message());
        if (shouldBlock(event.getPlayer(), text)) event.setCancelled(true);
    }

    @EventHandler(priority = EventPriority.LOWEST, ignoreCancelled = true)
    public void onCommand(PlayerCommandPreprocessEvent event) {
        if (!enabled()) return;
        String raw = event.getMessage();
        String body = raw.startsWith("/") ? raw.substring(1) : raw;
        int space = body.indexOf(' ');
        String label = (space < 0 ? body : body.substring(0, space)).toLowerCase(Locale.ROOT);
        int colon = label.indexOf(':');
        if (colon >= 0) label = label.substring(colon + 1);
        if (!monitored.contains(label)) return;

        String text = space < 0 ? "" : body.substring(space + 1);
        if (shouldBlock(event.getPlayer(), text)) event.setCancelled(true);
    }

    private boolean shouldBlock(Player player, String text) {
        if (player.hasPermission("capai.adbypass")) return false;

        FileConfiguration cfg = plugin.getConfig();
        UUID id = player.getUniqueId();

        if (cfg.getBoolean("adguard.internal-mute", true)) {
            long rem = plugin.getMuteManager().remaining(id);
            if (rem > 0) {
                player.sendMessage(plugin.msg("prefix") + plugin.msg("muted")
                        .replace("%time%", MuteManager.format(rem)));
                return true;
            }
        }

        String hit = detector.check(text);
        if (hit == null) return false;

        punish(player, text, hit);
        return true;
    }

    private void punish(Player player, String text, String hit) {
        FileConfiguration cfg = plugin.getConfig();
        UUID id = player.getUniqueId();
        String name = player.getName();

        int minutes = plugin.getMuteManager().punish(id, name,
                cfg.getIntegerList("adguard.mute-minutes"),
                cfg.getInt("adguard.strike-reset-days", 14));

        plugin.getStats().onAdMute();
        String shown = text.length() > 120 ? text.substring(0, 120) + "..." : text;
        plugin.getLogger().warning("Reklama: " + name + " -> \"" + shown + "\" (topildi: " + hit
                + ") | mute: " + minutes + " daqiqa");

        // Bukkit API'ni asosiy oqimda ishlatamiz
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            if (player.isOnline()) {
                player.sendMessage(plugin.msg("prefix") + plugin.msg("ad-warn")
                        .replace("%minutes%", String.valueOf(minutes)));
            }

            String cmd = cfg.getString("adguard.console-command", "");
            if (cmd != null && !cmd.isBlank()) {
                Bukkit.dispatchCommand(Bukkit.getConsoleSender(),
                        cmd.replace("%player%", name).replace("%minutes%", String.valueOf(minutes)));
            }

            if (cfg.getBoolean("telegram.notify-ad-mutes", true)) {
                plugin.getTelegram().notify("🚫 Reklama aniqlandi\nO'yinchi: " + name
                        + "\nXabar: " + shown + "\nTopildi: " + hit
                        + "\nJazo: " + minutes + " daqiqa mute (avtomatik)");
            }

            if (cfg.getBoolean("adguard.notify-staff", true)) {
                String note = plugin.msg("ad-notify")
                        .replace("%player%", name)
                        .replace("%minutes%", String.valueOf(minutes))
                        .replace("%message%", shown.replace("§", ""));
                for (Player staff : Bukkit.getOnlinePlayers()) {
                    if (staff.hasPermission("capai.notify")) staff.sendMessage(note);
                }
            }
        });
    }
}
