package uz.capmine.capai;

import org.bukkit.Bukkit;

/** Serverni to'xtatish / qayta ishga tushirish. */
public final class ServerPower {
    private final CapAI plugin;

    public ServerPower(CapAI plugin) { this.plugin = plugin; }

    private int delay() {
        return Math.max(0, plugin.getConfig().getInt("telegram.power.delay-seconds", 10));
    }

    public void stop(Out out) {
        schedule(out, "stop-warning", "🛑 Server o'chirilmoqda", Bukkit::shutdown);
    }

    public void restart(Out out) {
        schedule(out, "restart-warning", "♻️ Server qayta ishga tushirilmoqda", () -> {
            PanelClient panel = plugin.getPanel();
            if (panel.isEnabled()) {
                plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
                    try {
                        panel.power("restart");
                    } catch (Exception e) {
                        plugin.getLogger().warning("Panel restart xatosi: " + ServerInspector.redact(String.valueOf(e.getMessage())));
                        plugin.getServer().getScheduler().runTask(plugin, () -> Bukkit.spigot().restart());
                    }
                });
            } else {
                Bukkit.spigot().restart();
            }
        });
    }

    private void schedule(Out out, String warnKey, String info, Runnable action) {
        int d = delay();
        plugin.getServer().getScheduler().runTask(plugin, () -> {
            Bukkit.broadcastMessage(plugin.msg("prefix") + plugin.msg(warnKey).replace("%seconds%", String.valueOf(d)));
            out.raw(info + " (" + d + " soniyadan keyin).");
            plugin.getServer().getScheduler().runTaskLater(plugin, action, d * 20L);
        });
    }

    /** Har qanday oqimdan chaqirish mumkin (asosiy oqim qotib qolgan bo'lsa ham ishlaydi). */
    public void panelSignal(Out out, String signal) {
        PanelClient panel = plugin.getPanel();
        if (!panel.isEnabled()) {
            out.raw("Panel API sozlanmagan (config.yml → telegram.panel).");
            return;
        }
        try {
            panel.power(signal);
            out.raw("✅ Panelga '" + signal + "' signali yuborildi.");
        } catch (Exception e) {
            out.raw("❌ Panel xatosi: " + ServerInspector.redact(String.valueOf(e.getMessage())));
        }
    }
}
