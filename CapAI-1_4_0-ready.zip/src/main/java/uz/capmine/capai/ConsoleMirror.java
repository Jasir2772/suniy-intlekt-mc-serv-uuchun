package uz.capmine.capai;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.nio.charset.StandardCharsets;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** logs/latest.log ni kuzatib, konsol satrlarini Telegram'ga yuboradi. */
public final class ConsoleMirror {
    private static final Pattern HEADER = Pattern.compile("^\\[\\d\\d:\\d\\d:\\d\\d] \\[[^/\\]]+/(INFO|WARN|ERROR|FATAL|DEBUG)]");
    private static final Pattern ANSI = Pattern.compile("\\u001B\\[[;\\d]*m");

    private static final class Capture {
        final long until;
        final Out out;

        Capture(long until, Out out) {
            this.until = until;
            this.out = out;
        }
    }

    private final CapAI plugin;
    private volatile boolean running;
    private Thread thread;
    private volatile String modeOverride;
    private final Map<String, Capture> captures = new ConcurrentHashMap<>();
    private final Deque<String> batch = new ArrayDeque<>();
    private int dropped;
    private long lastSend;

    public ConsoleMirror(CapAI plugin) { this.plugin = plugin; }

    public String mode() {
        String m = modeOverride != null ? modeOverride : plugin.getConfig().getString("telegram.console-mirror", "off");
        m = m == null ? "off" : m.toLowerCase(Locale.ROOT);
        return (m.equals("warn") || m.equals("all")) ? m : "off";
    }

    public void setMode(String mode) { this.modeOverride = mode; }

    /** Komanda bajarilgandan keyin bir necha soniya konsol javobini shu chatga yuboradi. */
    public void capture(String chatId, long millis) {
        Capture old = captures.get(chatId);
        Out out = (old != null && old.until > System.currentTimeMillis()) ? old.out : plugin.getTelegram().chatOut(chatId);
        captures.put(chatId, new Capture(System.currentTimeMillis() + millis, out));
    }

    public void start() {
        running = true;
        thread = new Thread(this::loop, "CapAI-ConsoleTail");
        thread.setDaemon(true);
        thread.start();
    }

    public void stop() {
        running = false;
        if (thread != null) thread.interrupt();
    }

    private void loop() {
        File file = new File("logs/latest.log");
        long pos = file.exists() ? file.length() : 0;
        String level = "INFO";

        while (running) {
            try {
                Thread.sleep(1500);
                if (!plugin.getTelegram().isEnabled()) {
                    pos = file.exists() ? file.length() : 0;
                    continue;
                }
                if (!file.exists()) {
                    pos = 0;
                    continue;
                }
                long len = file.length();
                if (len < pos) pos = 0;
                if (len > pos) {
                    long start = pos;
                    if (len - start > 300_000) start = len - 300_000;
                    byte[] data = read(file, start, (int) (len - start));
                    int lastNl = -1;
                    for (int i = data.length - 1; i >= 0; i--) {
                        if (data[i] == '\n') {
                            lastNl = i;
                            break;
                        }
                    }
                    if (lastNl >= 0) {
                        pos = start + lastNl + 1;
                        String text = new String(data, 0, lastNl, StandardCharsets.UTF_8);
                        for (String raw : text.split("\\r?\\n")) level = process(raw, level);
                    }
                }
                flushIfDue();
            } catch (InterruptedException e) {
                return;
            } catch (Exception ignored) {
            }
        }
    }

    private static byte[] read(File f, long start, int len) throws IOException {
        try (RandomAccessFile raf = new RandomAccessFile(f, "r")) {
            raf.seek(start);
            byte[] b = new byte[len];
            raf.readFully(b);
            return b;
        }
    }

    private String process(String raw, String prevLevel) {
        String line = ANSI.matcher(raw).replaceAll("");
        Matcher m = HEADER.matcher(line);
        String level = m.find() ? m.group(1) : prevLevel;
        if (line.isBlank() || level.equals("DEBUG")) return level;
        if (line.contains("[CapAI]") && line.contains("Telegram")) return level;

        String mode = mode();
        boolean forward = mode.equals("all")
                || (mode.equals("warn") && (level.equals("WARN") || level.equals("ERROR") || level.equals("FATAL")));

        long now = System.currentTimeMillis();
        captures.entrySet().removeIf(e -> e.getValue().until < now);
        if (!forward && captures.isEmpty()) return level;

        String safe = ServerInspector.redact(line);
        if (safe.length() > 400) safe = safe.substring(0, 400) + "…";

        if (forward) {
            if (batch.size() >= 150) {
                batch.pollFirst();
                dropped++;
            }
            batch.addLast(safe);
        }
        for (Capture cap : captures.values()) cap.out.raw(safe);
        return level;
    }

    private void flushIfDue() {
        if (batch.isEmpty()) return;
        long now = System.currentTimeMillis();
        if (now - lastSend < 5000) return;

        StringBuilder sb = new StringBuilder("🖥️ Konsol\n");
        if (dropped > 0) {
            sb.append("(… ").append(dropped).append(" qator tashlab yuborildi)\n");
            dropped = 0;
        }
        while (!batch.isEmpty() && sb.length() + batch.peekFirst().length() < 3800) {
            sb.append(batch.pollFirst()).append('\n');
        }
        lastSend = now;
        plugin.getTelegram().notifyConsole(sb.toString());
    }
}
