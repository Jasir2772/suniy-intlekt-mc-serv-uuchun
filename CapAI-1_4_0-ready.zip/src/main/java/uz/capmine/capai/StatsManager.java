package uz.capmine.capai;

import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/** Kunlik statistika (stats.yml). */
public final class StatsManager {
    private final CapAI plugin;
    private final File file;
    private LocalDate date;
    private final Set<UUID> unique = new HashSet<>();
    private int newPlayers;
    private int peak;
    private int chat;
    private int adMutes;
    private int swearMutes;
    private int aiQuestions;
    private int reports;

    public StatsManager(CapAI plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "stats.yml");
        this.date = TimeUtil.today(plugin.getConfig());
        load();
    }

    private void load() {
        if (!file.exists()) return;
        YamlConfiguration y = YamlConfiguration.loadConfiguration(file);
        if (!date.toString().equals(y.getString("date", ""))) return;
        for (String s : y.getStringList("unique")) {
            try {
                unique.add(UUID.fromString(s));
            } catch (IllegalArgumentException ignored) {
            }
        }
        newPlayers = y.getInt("new-players");
        peak = y.getInt("peak");
        chat = y.getInt("chat");
        adMutes = y.getInt("ad-mutes");
        swearMutes = y.getInt("swear-mutes");
        aiQuestions = y.getInt("ai-questions");
        reports = y.getInt("reports");
    }

    private void rollover() {
        LocalDate today = TimeUtil.today(plugin.getConfig());
        if (!today.equals(date)) {
            date = today;
            unique.clear();
            newPlayers = peak = chat = adMutes = swearMutes = aiQuestions = reports = 0;
        }
    }

    public synchronized void onJoin(Player p) {
        rollover();
        if (unique.add(p.getUniqueId()) && !p.hasPlayedBefore()) newPlayers++;
        peak = Math.max(peak, Bukkit.getOnlinePlayers().size());
    }

    public synchronized void sampleOnline(int online) {
        rollover();
        peak = Math.max(peak, online);
    }

    public synchronized void onChat() { rollover(); chat++; }
    public synchronized void onAdMute() { rollover(); adMutes++; }
    public synchronized void onSwearMute() { rollover(); swearMutes++; }
    public synchronized void onAiQuestion() { rollover(); aiQuestions++; }
    public synchronized void onReport() { rollover(); reports++; }

    public synchronized String report() {
        rollover();
        return "📊 Kunlik hisobot (" + date + ")\n"
                + "👥 O'yinchilar: " + unique.size() + " (yangi: " + newPlayers + ")\n"
                + "📈 Eng ko'p online: " + peak + "\n"
                + "💬 Chat xabarlari: " + chat + "\n"
                + "🚫 Reklama mute: " + adMutes + " | 🤬 So'kinish mute: " + swearMutes + "\n"
                + "📢 Shikoyatlar: " + reports + "\n"
                + "🤖 AI savollari: " + aiQuestions;
    }

    public synchronized void save() {
        rollover();
        YamlConfiguration y = new YamlConfiguration();
        y.set("date", date.toString());
        y.set("unique", unique.stream().map(UUID::toString).toList());
        y.set("new-players", newPlayers);
        y.set("peak", peak);
        y.set("chat", chat);
        y.set("ad-mutes", adMutes);
        y.set("swear-mutes", swearMutes);
        y.set("ai-questions", aiQuestions);
        y.set("reports", reports);
        try {
            plugin.getDataFolder().mkdirs();
            y.save(file);
        } catch (IOException e) {
            plugin.getLogger().warning("stats.yml saqlanmadi: " + e.getMessage());
        }
    }
}
