package uz.capmine.capai;

import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.configuration.file.FileConfiguration;

import java.io.File;
import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicBoolean;

/** /capadmin: owner uchun yordamchi. Telegram bot ham shu mantiqdan foydalanadi. */
public final class AdminCommand implements CommandExecutor, TabCompleter {
    private enum Mode { CRASH, CHECK, ASK }

    private static final List<String> SUBS = List.of("status", "crash", "check", "ask", "mutes", "unmute", "reload");

    private final CapAI plugin;
    private final AtomicBoolean running = new AtomicBoolean(false);

    public AdminCommand(CapAI plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        Out out = Out.of(plugin, sender);
        if (!sender.hasPermission("capai.admin")) {
            out.info(plugin.msg("no-permission"));
            return true;
        }
        if (args.length == 0) {
            help(out, label);
            return true;
        }
        execute(out, label, args[0], Arrays.copyOfRange(args, 1, args.length));
        return true;
    }

    /** Asosiy oqimda chaqirilishi kerak. */
    public void execute(Out out, String label, String sub, String[] rest) {
        switch (sub.toLowerCase(Locale.ROOT)) {
            case "status" -> status(out);
            case "crash" -> analyze(out, Mode.CRASH, null);
            case "check" -> analyze(out, Mode.CHECK, null);
            case "ask" -> {
                if (rest.length == 0) out.info("&eFoydalanish: &f/" + label + " ask <savol>");
                else analyze(out, Mode.ASK, String.join(" ", rest));
            }
            case "mutes" -> {
                List<String[]> list = plugin.getMuteManager().active();
                if (list.isEmpty()) {
                    out.info("&7Hozir mute qilingan o'yinchi yo'q.");
                } else {
                    for (String[] e : list) out.info("&f" + e[0] + " &7- qoldi: &f" + e[1]);
                }
            }
            case "unmute" -> {
                if (rest.length == 0) out.info("&eFoydalanish: &f/" + label + " unmute <o'yinchi>");
                else if (plugin.getMuteManager().unmute(rest[0])) out.info("&a" + rest[0] + " mute'dan chiqarildi.");
                else out.info("&c" + rest[0] + " topilmadi (mute ro'yxatida yo'q).");
            }
            case "reload" -> {
                plugin.reloadAll();
                out.info(plugin.msg("reloaded"));
            }
            default -> help(out, label);
        }
    }

    private void help(Out out, String label) {
        out.info("&e/" + label + " status &7- TPS, RAM, dunyolar");
        out.info("&e/" + label + " crash &7- oxirgi crash/xatolikni AI tahlil qiladi");
        out.info("&e/" + label + " check &7- serverga nima yetishmayotganini tekshiradi");
        out.info("&e/" + label + " ask <savol> &7- server holatini bilgan holda savol");
        out.info("&e/" + label + " mutes &7| &e/" + label + " unmute <ism> &7- reklama mute'lari");
        out.info("&e/" + label + " reload &7- configni qayta yuklash");
    }

    private void status(Out out) {
        Runtime rt = Runtime.getRuntime();
        long max = rt.maxMemory() >> 20;
        long used = (rt.totalMemory() - rt.freeMemory()) >> 20;
        double[] tps = Bukkit.getTPS();
        long upMin = ManagementFactory.getRuntimeMXBean().getUptime() / 60_000;

        out.info(String.format(Locale.ROOT, "&eTPS &7(1/5/15 daq)&f: %.1f / %.1f / %.1f",
                Math.min(20, tps[0]), Math.min(20, tps[1]), Math.min(20, tps[2])));
        out.info(String.format(Locale.ROOT, "&eMSPT&f: %.1f ms", Bukkit.getAverageTickTime()));
        out.info("&eRAM&f: " + used + " / " + max + " MB");
        out.info("&eOnline&f: " + Bukkit.getOnlinePlayers().size() + "/" + Bukkit.getMaxPlayers()
                + " &7| &eIshlash&f: " + (upMin / 60) + " soat " + (upMin % 60) + " daq");
        out.info("&eDisk bo'sh&f: " + (new File(".").getFreeSpace() >> 30) + " GB");
        for (World w : Bukkit.getWorlds()) {
            out.info("&7" + w.getName() + "&f: chunk " + w.getLoadedChunks().length
                    + ", entity " + w.getEntities().size());
        }
    }

    private void analyze(Out out, Mode mode, String question) {
        FileConfiguration cfg = plugin.getConfig();
        if (plugin.getAIClient().getApiKey().isBlank()) {
            out.info(plugin.msg("no-key"));
            return;
        }
        if (!running.compareAndSet(false, true)) {
            out.info(plugin.msg("admin-busy"));
            return;
        }
        out.info(plugin.msg("admin-working"));

        String snap;
        try {
            snap = ServerInspector.snapshot(plugin);
        } catch (Exception e) {
            running.set(false);
            plugin.getLogger().warning("Snapshot xatosi: " + e);
            out.info(plugin.msg("admin-error"));
            return;
        }
        final String snapshot = snap;

        final int maxTokens = cfg.getInt("admin.max-tokens", 1200);
        final int timeout = cfg.getInt("admin.timeout-seconds", 60);
        final int ctx = cfg.getInt("admin.max-context-chars", 14000);
        String adminModel = cfg.getString("api.admin-model", "");
        final String model = (adminModel == null || adminModel.isBlank())
                ? cfg.getString("api.model", "gpt-4o-mini") : adminModel;

        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, () -> {
            String answer = null;
            String saved = null;
            boolean ok = true;
            try {
                String logs = ServerInspector.logContext(mode == Mode.CRASH, ctx);
                String user = "=== SERVER HOLATI ===\n" + snapshot + "\n" + logs;
                if (mode == Mode.ASK) user += "\n=== EGASINING SAVOLI ===\n" + question + "\n";
                user = ServerInspector.redact(user);

                answer = plugin.getAIClient().complete(systemPrompt(mode), user, model, maxTokens, timeout);
                try {
                    saved = saveReport(mode, answer);
                } catch (IOException e) {
                    plugin.getLogger().warning("Hisobot saqlanmadi: " + e.getMessage());
                }
            } catch (Exception e) {
                ok = false;
                plugin.getLogger().warning("CapAI admin xatosi: " + ServerInspector.redact(String.valueOf(e.getMessage())));
            }
            running.set(false);

            if (!plugin.isEnabled()) return;
            final String a = answer;
            final String sv = saved;
            final boolean success = ok;
            plugin.getServer().getScheduler().runTask(plugin, () -> deliver(out, success, a, sv));
        });
    }

    private void deliver(Out out, boolean success, String answer, String savedPath) {
        if (!out.valid()) return;
        if (!success) {
            out.info(plugin.msg("admin-error"));
            return;
        }

        int max = plugin.getConfig().getInt("admin.max-answer-length", 3500);
        boolean truncated = false;
        if (answer.length() > max) {
            int cut = answer.lastIndexOf('\n', max);
            answer = answer.substring(0, cut > 0 ? cut : max);
            truncated = true;
        }

        out.info("&aAI tahlili:");
        for (String line : answer.split("\\R")) {
            if (line.isBlank()) continue;
            out.raw(line);
        }
        if (truncated && savedPath != null) {
            out.info("&7Javob uzun edi. To'liq matn: &f" + savedPath);
        }
    }

    private String saveReport(Mode mode, String answer) throws IOException {
        Path dir = plugin.getDataFolder().toPath().resolve("reports");
        Files.createDirectories(dir);
        String name = mode.name().toLowerCase(Locale.ROOT) + "-"
                + LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss")) + ".txt";
        Files.writeString(dir.resolve(name), answer, StandardCharsets.UTF_8);
        return "plugins/CapAI/reports/" + name;
    }

    private String systemPrompt(Mode mode) {
        String base = """
                Sen tajribali Minecraft (Paper/Spigot) server administratori va Java dasturchisisan.
                Server egasiga yordam berasan. Senga server holati (versiya, Java, RAM, TPS, pluginlar,
                sozlamalar) va loglardan parchalar beriladi. IP manzillar va parollar yashirilgan (x.x.x.x).
                Qoidalar:
                - O'zbek tilida, sodda va aniq yoz. Markdown ishlatma (**, #, `); ro'yxat uchun raqam yoki "-" ishlat.
                - Faqat berilgan ma'lumotlarga tayan. Ma'lumot yetarli bo'lmasa, buni ayt va qaysi faylni/ma'lumotni
                  yuborish kerakligini ayt. Taxmin qilsang, "taxminan" deb belgila.
                - Sababni aniq ko'rsat (qaysi plugin, qaysi xato qatori), keyin tuzatish qadamlarini raqamlab ber.
                - Mavjud bo'lmagan komanda yoki sozlama nomlarini uydirma.
                - Tayyor (sborka) pluginlar eskirgan yoki serverning versiyasiga mos kelmasligi mumkin, shunga e'tibor ber.
                """;
        String task = switch (mode) {
            case CRASH -> """
                    Vazifa: serverning oxirgi crash yoki jiddiy xatoligi sababini top.
                    Format: "Sabab" (1-3 gap), keyin "Nima qilish kerak" (raqamlangan qadamlar).
                    Agar crash aniq ko'rinmasa, eng ehtimoliy sabablarni ustuvorlik bilan yoz.
                    """;
            case CHECK -> """
                    Vazifa: serverni umumiy tekshir va (1) mavjud muammo/xavflar, (2) yetishmayotgan muhim narsalar
                    (masalan: anti-cheat, backup, permissions, lag optimizatsiyasi, anti-crash/xavfsizlik),
                    (3) performance sozlamalari (RAM, JVM flaglar, view/simulation-distance) bo'yicha tavsiya ber.
                    Ustuvorlik bo'yicha tartiblab, ko'pi bilan 8 ta punkt yoz.
                    """;
            case ASK -> """
                    Vazifa: server egasining savoliga server holatiga tayangan holda javob ber.
                    """;
        };
        return base + task;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!sender.hasPermission("capai.admin")) return List.of();
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            String typed = args[0].toLowerCase(Locale.ROOT);
            for (String s : SUBS) if (s.startsWith(typed)) out.add(s);
        } else if (args.length == 2 && args[0].equalsIgnoreCase("unmute")) {
            String typed = args[1].toLowerCase(Locale.ROOT);
            for (String[] e : plugin.getMuteManager().active()) {
                if (e[0].toLowerCase(Locale.ROOT).startsWith(typed)) out.add(e[0]);
            }
        }
        return out;
    }
}
