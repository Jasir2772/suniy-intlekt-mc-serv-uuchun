package uz.capmine.capai;

import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/** Buyruq natijasi qayerga borishini (o'yin chati, konsol yoki Telegram) yashiradi. */
public interface Out {
    /** & rang kodlari bilan yozilgan xabar. */
    void info(String text);

    /** Rang kodlarisiz, aynan shu matn (masalan, AI javobi). */
    void raw(String text);

    default boolean valid() { return true; }

    static Out of(CapAI plugin, CommandSender sender) {
        return new Out() {
            @Override
            public void info(String text) {
                sender.sendMessage(plugin.msg("prefix") + plugin.color(text));
            }

            @Override
            public void raw(String text) {
                sender.sendMessage(text.replace("§", ""));
            }

            @Override
            public boolean valid() {
                return !(sender instanceof Player p) || p.isOnline();
            }
        };
    }
}
