package uz.capmine.capai;

import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Chat xabarida boshqa serverga reklama (IP, domen, iboralar) borligini aniqlaydi. */
public final class AdDetector {
    private static final String TLDS =
            "com|net|org|ru|uz|gg|fun|pro|xyz|io|me|su|ua|kz|world|online|club|site|top|cc|eu|host|space|store|tech|live|pw|tk|ml|ga|cf|gq|lol|cloud";

    private static final Pattern IP = Pattern.compile(
            "(?<![\\d.])(?:(?:25[0-5]|2[0-4]\\d|1?\\d?\\d)\\.){3}(?:25[0-5]|2[0-4]\\d|1?\\d?\\d)(?::\\d{2,5})?(?!\\d)");

    private static final Pattern DOMAIN = Pattern.compile(
            "(?<![a-z0-9@.-])((?:[a-z0-9](?:[a-z0-9-]{0,40}[a-z0-9])?\\.)+(?:" + TLDS + "))(?![a-z0-9-])(?::\\d{2,5})?");

    private static final Pattern DOT_WORDS = Pattern.compile(
            "\\s*(?:\\(dot\\)|\\[dot\\]|\\{dot\\}|\\[\\.\\]|\\(\\.\\)|\\{\\.\\}|\\bdot\\b|\\bnuqta\\b|\\bточка\\b|\\bточку\\b)\\s*",
            Pattern.UNICODE_CHARACTER_CLASS);

    private static final Pattern INVISIBLE = Pattern.compile("[\\u200B-\\u200F\\u2060\\uFEFF]");

    private static final Map<Character, Character> HOMOGLYPHS = Map.ofEntries(
            Map.entry('а', 'a'), Map.entry('е', 'e'), Map.entry('о', 'o'), Map.entry('р', 'p'),
            Map.entry('с', 'c'), Map.entry('х', 'x'), Map.entry('у', 'y'), Map.entry('к', 'k'),
            Map.entry('м', 'm'), Map.entry('т', 't'), Map.entry('в', 'b'), Map.entry('н', 'h'));

    private final Set<String> allowedDomains = new HashSet<>();
    private final Set<String> allowedIps = new HashSet<>();
    private final List<String> phrases;

    public AdDetector(List<String> allowedDomains, List<String> allowedIps, List<String> phrases) {
        for (String d : allowedDomains) this.allowedDomains.add(d.toLowerCase(Locale.ROOT).trim());
        for (String ip : allowedIps) this.allowedIps.add(ip.trim());
        this.phrases = phrases.stream().map(p -> p.toLowerCase(Locale.ROOT).trim()).filter(p -> !p.isEmpty()).toList();
    }

    /** Reklama topilsa, topilgan qismni qaytaradi; aks holda null. */
    public String check(String text) {
        String t = INVISIBLE.matcher(text.toLowerCase(Locale.ROOT)).replaceAll("");
        t = DOT_WORDS.matcher(t).replaceAll(".");
        t = t.replaceAll("\\s+\\.\\s+", ".");
        t = t.replaceAll("(?<=[a-z0-9])\\s+\\.(?=[a-z0-9])", ".");

        for (String phrase : phrases) {
            if (t.contains(phrase)) return phrase;
        }

        StringBuilder sb = new StringBuilder(t.length());
        for (char c : t.toCharArray()) sb.append(HOMOGLYPHS.getOrDefault(c, c));
        String h = sb.toString();

        Matcher ipMatcher = IP.matcher(h);
        while (ipMatcher.find()) {
            String found = ipMatcher.group();
            String ip = found.contains(":") ? found.substring(0, found.indexOf(':')) : found;
            if (!allowedIps.contains(ip)) return found;
        }

        Matcher dm = DOMAIN.matcher(h);
        while (dm.find()) {
            if (!isAllowed(dm.group(1))) return dm.group();
        }
        return null;
    }

    private boolean isAllowed(String domain) {
        for (String a : allowedDomains) {
            if (domain.equals(a) || domain.endsWith("." + a)) return true;
        }
        return false;
    }
}
