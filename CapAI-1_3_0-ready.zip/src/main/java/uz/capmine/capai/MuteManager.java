package uz.capmine.capai;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Reklama uchun mute va strike'larni saqlaydi (mutes.yml). */
public final class MuteManager {
    private static final class Entry {
        final UUID id;
        String name = "";
        long until;
        int strikes;
        long last;

        Entry(UUID id) { this.id = id; }
    }

    private final CapAI plugin;
    private final File file;
    private final Map<UUID, Entry> entries = new HashMap<>();

    public MuteManager(CapAI plugin) {
        this.plugin = plugin;
        this.file = new File(plugin.getDataFolder(), "mutes.yml");
        load();
    }

    private void load() {
        if (!file.exists()) return;
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(file);
        ConfigurationSection sec = yaml.getConfigurationSection("entries");
        if (sec == null) return;
        for (String key : sec.getKeys(false)) {
            try {
                Entry e = new Entry(UUID.fromString(key));
                e.name = sec.getString(key + ".name", "");
                e.until = sec.getLong(key + ".until");
                e.strikes = sec.getInt(key + ".strikes");
                e.last = sec.getLong(key + ".last");
                entries.put(e.id, e);
            } catch (IllegalArgumentException ignored) {
            }
        }
    }

    /** Qolgan mute vaqti (millisekund), yo'q bo'lsa 0. */
    public synchronized long remaining(UUID id) {
        Entry e = entries.get(id);
        if (e == null) return 0;
        return Math.max(0, e.until - System.currentTimeMillis());
    }

    /** Strike qo'shadi va mute muddatini (daqiqada) qaytaradi. */
    public synchronized int punish(UUID id, String name, List<Integer> ladder, int resetDays) {
        long now = System.currentTimeMillis();
        Entry e = entries.computeIfAbsent(id, Entry::new);
        e.name = name;
        if (resetDays > 0 && e.last > 0 && now - e.last > resetDays * 86_400_000L) e.strikes = 0;
        e.strikes++;
        e.last = now;
        int minutes = 10;
        if (ladder != null && !ladder.isEmpty()) {
            minutes = ladder.get(Math.min(e.strikes - 1, ladder.size() - 1));
        }
        e.until = now + minutes * 60_000L;
        saveAsync();
        return minutes;
    }

    public synchronized boolean unmute(String name) {
        boolean found = false;
        for (Entry e : entries.values()) {
            if (e.name.equalsIgnoreCase(name)) {
                e.until = 0;
                found = true;
            }
        }
        if (found) saveAsync();
        return found;
    }

    /** {ism, qolgan vaqt} juftliklari. */
    public synchronized List<String[]> active() {
        List<String[]> out = new ArrayList<>();
        long now = System.currentTimeMillis();
        for (Entry e : entries.values()) {
            if (e.until > now) out.add(new String[]{e.name, format(e.until - now)});
        }
        return out;
    }

    public static String format(long ms) {
        long sec = Math.max(0, ms / 1000);
        long d = sec / 86_400, h = (sec % 86_400) / 3600, m = (sec % 3600) / 60, s = sec % 60;
        if (d > 0) return d + " kun " + h + " soat";
        if (h > 0) return h + " soat " + m + " daqiqa";
        if (m > 0) return m + " daqiqa " + s + " soniya";
        return s + " soniya";
    }

    private void saveAsync() {
        if (!plugin.isEnabled()) return;
        plugin.getServer().getScheduler().runTaskAsynchronously(plugin, this::save);
    }

    public synchronized void save() {
        YamlConfiguration yaml = new YamlConfiguration();
        long now = System.currentTimeMillis();
        for (Entry e : entries.values()) {
            if (e.until <= now && e.strikes <= 0) continue;
            String p = "entries." + e.id;
            yaml.set(p + ".name", e.name);
            yaml.set(p + ".until", e.until);
            yaml.set(p + ".strikes", e.strikes);
            yaml.set(p + ".last", e.last);
        }
        try {
            plugin.getDataFolder().mkdirs();
            yaml.save(file);
        } catch (IOException ex) {
            plugin.getLogger().warning("mutes.yml saqlanmadi: " + ex.getMessage());
        }
    }
}
