package uz.capmine.capai;

import org.bukkit.ChatColor;
import org.bukkit.command.PluginCommand;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;

public final class CapAI extends JavaPlugin implements Listener {
    private AIClient aiClient;
    private CooldownManager cooldownManager;
    private UsageManager usageManager;
    private ChatHistory chatHistory;
    private MuteManager muteManager;
    private AdGuard adGuard;
    private StaffWatcher staffWatcher;
    private TelegramBot telegram;
    private AdminCommand admin;
    private File lockFile;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        getDataFolder().mkdirs();

        // Oldingi sessiya to'g'ri yopilganmi? (running.lock o'chirilmagan bo'lsa, yo'q)
        lockFile = new File(getDataFolder(), "running.lock");
        boolean crashed = lockFile.exists();
        try {
            Files.writeString(lockFile.toPath(), String.valueOf(System.currentTimeMillis()));
        } catch (IOException e) {
            getLogger().warning("running.lock yozilmadi: " + e.getMessage());
        }

        aiClient = new AIClient(this);
        cooldownManager = new CooldownManager();
        usageManager = new UsageManager(this);
        chatHistory = new ChatHistory();
        muteManager = new MuteManager(this);
        adGuard = new AdGuard(this);
        staffWatcher = new StaffWatcher(this);
        telegram = new TelegramBot(this);
        admin = new AdminCommand(this);

        AICommand command = new AICommand(this);
        PluginCommand pc = getCommand("ai");
        if (pc != null) {
            pc.setExecutor(command);
            pc.setTabCompleter(command);
        }
        PluginCommand ac = getCommand("capadmin");
        if (ac != null) {
            ac.setExecutor(admin);
            ac.setTabCompleter(admin);
        }

        getServer().getPluginManager().registerEvents(this, this);
        getServer().getPluginManager().registerEvents(adGuard, this);
        getServer().getPluginManager().registerEvents(staffWatcher, this);

        telegram.start();
        new HealthMonitor(this).start();

        if (getConfig().getBoolean("telegram.notify-start-stop", true)) {
            telegram.notify("✅ Server ishga tushdi (CapAI v" + getDescription().getVersion() + ").");
        }
        if (crashed) handleUncleanShutdown();

        getLogger().info("CapAI v" + getDescription().getVersion() + " ishga tushdi!");
    }

    private void handleUncleanShutdown() {
        getLogger().warning("Oldingi sessiya to'g'ri yopilmagan (crash yoki majburiy o'chirish).");
        telegram.notify("⚠️ Server oldingi safar to'g'ri o'chirilmagan (crash yoki majburiy o'chirish bo'lishi mumkin).");

        boolean auto = getConfig().getBoolean("telegram.auto-crash-analysis", true);
        if (auto && telegram.isEnabled() && !aiClient.getApiKey().isBlank()) {
            // Server to'liq yuklanib bo'lgach (~30 soniya) tahlil qilamiz
            getServer().getScheduler().runTaskLater(this,
                    () -> admin.execute(telegram.broadcastOut(), "cap", "crash", new String[0]), 600L);
        }
    }

    @Override
    public void onDisable() {
        if (usageManager != null) usageManager.save();
        if (muteManager != null) muteManager.save();
        if (telegram != null) {
            telegram.stop();
            if (getConfig().getBoolean("telegram.notify-start-stop", true)) {
                telegram.notifyBlocking("🛑 Server to'xtadi.");
            }
        }
        if (lockFile != null) lockFile.delete();
    }

    public void reloadAll() {
        reloadConfig();
        aiClient = new AIClient(this);
        adGuard.reload();
        staffWatcher.reload();
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        cooldownManager.clear(event.getPlayer().getUniqueId());
        chatHistory.clear(event.getPlayer().getUniqueId());
    }

    public String color(String text) {
        return ChatColor.translateAlternateColorCodes('&', text == null ? "" : text);
    }

    public String msg(String key) {
        return color(getConfig().getString("messages." + key, ""));
    }

    public AIClient getAIClient() { return aiClient; }
    public CooldownManager getCooldownManager() { return cooldownManager; }
    public UsageManager getUsageManager() { return usageManager; }
    public ChatHistory getChatHistory() { return chatHistory; }
    public MuteManager getMuteManager() { return muteManager; }
    public TelegramBot getTelegram() { return telegram; }
    public AdminCommand getAdmin() { return admin; }
}
