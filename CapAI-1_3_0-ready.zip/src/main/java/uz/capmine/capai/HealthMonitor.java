package uz.capmine.capai;

import org.bukkit.Bukkit;
import org.bukkit.configuration.file.FileConfiguration;

import java.time.LocalDate;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Locale;

/** Har daqiqada TPS va RAM'ni tekshiradi, muammo bo'lsa Telegram'ga xabar beradi. */
public final class HealthMonitor {
    private final CapAI plugin;
    private int lowTps;
    private int highRam;
    private long lastLagAlert;
    private long lastRamAlert;
    private LocalDate lastDaily;

    public HealthMonitor(CapAI plugin) { this.plugin = plugin; }

    public void start() {
        plugin.getServer().getScheduler().runTaskTimer(plugin, this::tick, 1200L, 1200L);
    }

    private void tick() {
        TelegramBot tg = plugin.getTelegram();
        if (!tg.isEnabled()) return;

        FileConfiguration c = plugin.getConfig();
        long now = System.currentTimeMillis();
        long cooldown = c.getLong("telegram.alert-cooldown-minutes", 15) * 60_000L;

        double tpsLimit = c.getDouble("telegram.lag-alert-tps", 15);
        double tps = Math.min(20.0, Bukkit.getTPS()[0]);
        lowTps = (tpsLimit > 0 && tps < tpsLimit) ? lowTps + 1 : 0;
        if (lowTps >= 3 && now - lastLagAlert > cooldown) {
            lastLagAlert = now;
            tg.notify(String.format(Locale.ROOT,
                    "🐢 Server lag qilmoqda: TPS %.1f, MSPT %.1f ms, online %d.\nSababini bilish uchun /check yuboring.",
                    tps, Bukkit.getAverageTickTime(), Bukkit.getOnlinePlayers().size()));
        }

        int ramLimit = c.getInt("telegram.ram-alert-percent", 90);
        Runtime rt = Runtime.getRuntime();
        double pct = (rt.totalMemory() - rt.freeMemory()) * 100.0 / rt.maxMemory();
        highRam = (ramLimit > 0 && pct >= ramLimit) ? highRam + 1 : 0;
        if (highRam >= 3 && now - lastRamAlert > cooldown) {
            lastRamAlert = now;
            tg.notify(String.format(Locale.ROOT,
                    "🧠 RAM to'lib bormoqda: %.0f%% (%d / %d MB). Crash xavfi bor.\nTavsiya uchun /check yuboring.",
                    pct, (rt.totalMemory() - rt.freeMemory()) >> 20, rt.maxMemory() >> 20));
        }

        int hour = c.getInt("telegram.daily-check-hour", -1);
        if (hour >= 0) {
            ZoneId zone;
            try {
                zone = ZoneId.of(c.getString("settings.timezone", "Asia/Tashkent"));
            } catch (Exception e) {
                zone = ZoneId.systemDefault();
            }
            ZonedDateTime zdt = ZonedDateTime.now(zone);
            if (zdt.getHour() == hour && !zdt.toLocalDate().equals(lastDaily)) {
                lastDaily = zdt.toLocalDate();
                tg.notify("📋 Kunlik server tekshiruvi:");
                plugin.getAdmin().execute(tg.broadcastOut(), "cap", "check", new String[0]);
            }
        }
    }
}
