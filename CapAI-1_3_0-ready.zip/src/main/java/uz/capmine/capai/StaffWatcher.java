package uz.capmine.capai;

import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.server.ServerCommandEvent;

import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/** Adminlar mute/ban/kick kabi komandalar ishlatganda Telegram'ga xabar beradi. */
public final class StaffWatcher implements Listener {
    private final CapAI plugin;
    private volatile Set<String> watched;

    public StaffWatcher(CapAI plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        Set<String> set = new HashSet<>();
        for (String s : plugin.getConfig().getStringList("telegram.watched-commands")) {
            set.add(s.toLowerCase(Locale.ROOT));
        }
        watched = set;
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlayerCommand(PlayerCommandPreprocessEvent event) {
        Player p = event.getPlayer();
        if (!(p.isOp() || p.hasPermission("capai.notify"))) return;
        handle(p.getName(), event.getMessage());
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onConsoleCommand(ServerCommandEvent event) {
        if (!(event.getSender() instanceof ConsoleCommandSender)) return;
        handle("Konsol", "/" + event.getCommand());
    }

    private void handle(String who, String command) {
        if (!plugin.getConfig().getBoolean("telegram.notify-staff-commands", true)) return;

        String body = command.startsWith("/") ? command.substring(1) : command;
        int space = body.indexOf(' ');
        String label = (space < 0 ? body : body.substring(0, space)).toLowerCase(Locale.ROOT);
        int colon = label.indexOf(':');
        if (colon >= 0) label = label.substring(colon + 1);
        if (!watched.contains(label)) return;

        String shown = command.length() > 300 ? command.substring(0, 300) + "..." : command;
        plugin.getTelegram().notify("🔧 " + who + " komanda ishlatdi:\n" + shown);
    }
}
