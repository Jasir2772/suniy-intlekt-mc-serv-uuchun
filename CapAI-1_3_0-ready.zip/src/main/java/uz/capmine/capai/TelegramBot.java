package uz.capmine.capai;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.Executors;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

/** Telegram: adminlarga xabar yuboradi va adminlardan buyruq qabul qiladi. */
public final class TelegramBot {
    private static final Pattern COLOR = Pattern.compile("(?i)[&§][0-9a-fk-or]");

    private final CapAI plugin;
    private final HttpClient http = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(10)).build();
    private final ScheduledExecutorService sender = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread t = new Thread(r, "CapAI-TG-Send");
        t.setDaemon(true);
        return t;
    });
    private volatile boolean running;
    private Thread poller;
    private String lastWarn = "";
    private long lastWarnAt;

    public TelegramBot(CapAI plugin) { this.plugin = plugin; }

    // ---------- config ----------

    private String token() {
        return plugin.getConfig().getString("telegram.bot-token", "").trim();
    }

    public boolean isEnabled() {
        return plugin.getConfig().getBoolean("telegram.enabled", false) && !token().isBlank();
    }

    private List<String> ids(String path) {
        List<String> out = new ArrayList<>();
        List<?> raw = plugin.getConfig().getList(path);
        if (raw != null) for (Object o : raw) out.add(String.valueOf(o).trim());
        return out;
    }

    // ---------- yuborish ----------

    /** Barcha chat-ids ga xabar yuboradi (asinxron). */
    public void notify(String text) {
        if (!isEnabled()) return;
        for (String chat : ids("telegram.chat-ids")) {
            try {
                sender.execute(() -> post(chat, text, 15));
            } catch (RejectedExecutionException ignored) {
            }
        }
    }

    /** onDisable uchun: bloklovchi yuborish (qisqa timeout). */
    public void notifyBlocking(String text) {
        if (!isEnabled()) return;
        for (String chat : ids("telegram.chat-ids")) post(chat, text, 5);
    }

    private void post(String chatId, String text, int timeoutSec) {
        for (String part : split(text)) {
            JsonObject body = new JsonObject();
            body.addProperty("chat_id", chatId);
            body.addProperty("text", part);
            body.addProperty("disable_web_page_preview", true);
            try {
                call("sendMessage", body, timeoutSec);
            } catch (Exception e) {
                warn("Telegram'ga yuborilmadi", e);
            }
        }
    }

    private static List<String> split(String text) {
        List<String> parts = new ArrayList<>();
        String rest = text;
        while (rest.length() > 4000) {
            int cut = rest.lastIndexOf('\n', 4000);
            if (cut < 1) cut = 4000;
            parts.add(rest.substring(0, cut));
            rest = rest.substring(cut).stripLeading();
        }
        if (!rest.isBlank()) parts.add(rest);
        return parts;
    }

    private JsonObject call(String method, JsonObject body, int timeoutSec) throws Exception {
        for (int attempt = 0; ; attempt++) {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create("https://api.telegram.org/bot" + token() + "/" + method))
                    .timeout(Duration.ofSeconds(timeoutSec))
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(body.toString()))
                    .build();
            HttpResponse<String> resp = http.send(request, HttpResponse.BodyHandlers.ofString());
            JsonObject json = JsonParser.parseString(resp.body()).getAsJsonObject();
            if (json.has("ok") && json.get("ok").getAsBoolean()) return json;

            int code = json.has("error_code") ? json.get("error_code").getAsInt() : resp.statusCode();
            if (code == 429 && attempt == 0) {
                long wait = 2;
                if (json.has("parameters") && json.getAsJsonObject("parameters").has("retry_after"))
                    wait = Math.min(10, json.getAsJsonObject("parameters").get("retry_after").getAsLong());
                Thread.sleep(wait * 1000);
                continue;
            }
            String desc = json.has("description") ? json.get("description").getAsString() : "noma'lum xato";
            throw new IllegalStateException("Telegram " + code + ": " + desc);
        }
    }

    private String safe(String s) {
        String t = token();
        if (s == null) return "";
        return t.isEmpty() ? s : s.replace(t, "<TOKEN>");
    }

    private void warn(String what, Exception e) {
        String msg = what + ": " + safe(e.getMessage());
        long now = System.currentTimeMillis();
        if (msg.equals(lastWarn) && now - lastWarnAt < 300_000) return;
        lastWarn = msg;
        lastWarnAt = now;
        plugin.getLogger().warning(msg);
    }

    // ---------- Out (Telegram chatiga natija) ----------

    private final class ChatOut implements Out {
        private final String chatId;
        private final StringBuilder buf = new StringBuilder();
        private ScheduledFuture<?> pending;

        ChatOut(String chatId) { this.chatId = chatId; }

        @Override
        public void info(String text) { add(COLOR.matcher(text).replaceAll("")); }

        @Override
        public void raw(String text) { add(text); }

        private synchronized void add(String line) {
            buf.append(line).append('\n');
            if (pending != null) pending.cancel(false);
            try {
                pending = sender.schedule(this::flush, 600, TimeUnit.MILLISECONDS);
            } catch (RejectedExecutionException ignored) {
            }
        }

        private synchronized void flush() {
            String text = buf.toString().trim();
            buf.setLength(0);
            pending = null;
            if (!text.isEmpty()) post(chatId, text, 15);
        }
    }

    public Out chatOut(String chatId) { return new ChatOut(chatId); }

    /** Barcha chat-ids ga yuboradigan Out. */
    public Out broadcastOut() {
        List<Out> outs = new ArrayList<>();
        for (String id : ids("telegram.chat-ids")) outs.add(new ChatOut(id));
        return new Out() {
            @Override
            public void info(String text) { for (Out o : outs) o.info(text); }

            @Override
            public void raw(String text) { for (Out o : outs) o.raw(text); }
        };
    }

    // ---------- qabul qilish (long polling) ----------

    public void start() {
        running = true;
        poller = new Thread(this::pollLoop, "CapAI-TG-Poll");
        poller.setDaemon(true);
        poller.start();
    }

    public void stop() {
        running = false;
        if (poller != null) poller.interrupt();
        sender.shutdown();
        try {
            sender.awaitTermination(3, TimeUnit.SECONDS);
        } catch (InterruptedException ignored) {
            Thread.currentThread().interrupt();
        }
    }

    private void pollLoop() {
        long offset = 0;
        boolean init = false;
        while (running) {
            try {
                if (!isEnabled()) {
                    init = false;
                    Thread.sleep(10_000);
                    continue;
                }
                if (!init) {
                    // eski (to'planib qolgan) buyruqlarni o'tkazib yuboramiz
                    JsonObject b = new JsonObject();
                    b.addProperty("offset", -1);
                    b.addProperty("timeout", 0);
                    JsonArray old = call("getUpdates", b, 15).getAsJsonArray("result");
                    if (old.size() > 0) {
                        offset = old.get(old.size() - 1).getAsJsonObject().get("update_id").getAsLong() + 1;
                    }
                    init = true;
                }

                JsonObject b = new JsonObject();
                b.addProperty("offset", offset);
                b.addProperty("timeout", 25);
                JsonArray updates = call("getUpdates", b, 40).getAsJsonArray("result");
                for (JsonElement el : updates) {
                    JsonObject u = el.getAsJsonObject();
                    offset = Math.max(offset, u.get("update_id").getAsLong() + 1);
                    try {
                        handleUpdate(u);
                    } catch (Exception e) {
                        warn("Telegram buyrug'i xatosi", e);
                    }
                }
            } catch (InterruptedException ie) {
                return;
            } catch (Exception e) {
                warn("Telegram'dan o'qib bo'lmadi", e);
                try {
                    Thread.sleep(5_000);
                } catch (InterruptedException ie) {
                    return;
                }
            }
        }
    }

    private void handleUpdate(JsonObject u) {
        JsonObject msg = u.has("message") ? u.getAsJsonObject("message") : null;
        if (msg == null || !msg.has("text") || !msg.has("chat")) return;

        String text = msg.get("text").getAsString().trim();
        if (!text.startsWith("/")) return;

        String chatId = String.valueOf(msg.getAsJsonObject("chat").get("id").getAsLong());
        String userId = msg.has("from") ? String.valueOf(msg.getAsJsonObject("from").get("id").getAsLong()) : "";

        String[] parts = text.split("\\s+", 2);
        String cmd = parts[0].substring(1).toLowerCase(Locale.ROOT);
        int at = cmd.indexOf('@');
        if (at >= 0) cmd = cmd.substring(0, at);
        String arg = parts.length > 1 ? parts[1].trim() : "";

        Out out = chatOut(chatId);

        if (cmd.equals("id")) {
            out.raw("Sizning user ID: " + userId + "\nChat ID: " + chatId);
            return;
        }
        if (userId.isEmpty() || !ids("telegram.admin-user-ids").contains(userId)) {
            out.raw("Ruxsat yo'q. /id yuboring va user ID'ni config.yml dagi telegram.admin-user-ids ga yozing.");
            return;
        }

        final String sub = cmd;
        final String[] rest = arg.isEmpty() ? new String[0] : arg.split("\\s+");
        switch (sub) {
            case "status", "crash", "check", "ask", "mutes", "unmute" ->
                    plugin.getServer().getScheduler().runTask(plugin,
                            () -> plugin.getAdmin().execute(out, "cap", sub, rest));
            default -> out.raw("""
                    CapAI buyruqlari:
                    /status - TPS, RAM, dunyolar
                    /crash - oxirgi crashni AI tahlil qiladi
                    /check - serverga nima yetishmayotganini tekshiradi
                    /ask <savol> - server haqida savol
                    /mutes - mute qilinganlar
                    /unmute <ism> - mute'dan chiqarish
                    /id - Telegram ID'ingiz""");
        }
    }
}
